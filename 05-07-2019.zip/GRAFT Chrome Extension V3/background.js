chrome.browserAction.onClicked.addListener(function (tab) {
    chrome.tabs.query({
        currentWindow: true,
        active: true
    }, function (tabs) {
        var updateProperties = {
            "active": true
        };
        chrome.tabs.update(tabs[0].id, updateProperties, function (tab) {
			chrome.storage.sync.set({
				'fromContextMenu': false
			});
            chrome.tabs.executeScript(tab.id, {
                file: "content_script.js"
            }, function () {
                if (chrome.runtime.lastError) {
                    alert('Current page is blocking extension');
                    return;
                }
            });

        });
    });
});

rightClickListner = function(event){
	chrome.storage.sync.set({
		'fromContextMenu': true
		});
	var params = {
		active: true ,
		currentWindow: true
	}
	chrome.tabs.query(params,function(tab){
		chrome.tabs.executeScript(tab.id, {
                file: "content_script.js"
            }, function () {
                if (chrome.runtime.lastError) {
                    alert('Current page is blocking extension');
                    return;
                }
            });
	});
	
}

chrome.contextMenus.create({
	title: "Inspect with GRAFT",
	contexts:["all"], 
	onclick: rightClickListner
});