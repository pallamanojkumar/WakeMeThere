
function getAbsXpath(element){
	if (!(element instanceof Element))
        return;
    var path = [];
	var newArr = [];
	
	while (element.nodeType === Node.ELEMENT_NODE) {
		var selector2 = element.nodeName.toLowerCase();
		var sib = element,
			nth = 1;
			while (sib = sib.previousElementSibling) {
				if (sib.nodeName.toLowerCase() == selector2)
					nth++
			}
			selector2 += "[" + nth + "]";
			path.unshift(selector2);
			element = element.parentNode;
			
	}
	return "//"+path.join("/");
}
window.oncontextmenu = function(event) {
	//console.log(event.pageX - window.pageXOffset, event.pageY - window.pageYOffset);
	//console.log(event.target)
	//console.log(getAbsXpath(event.target));
	chrome.storage.sync.set({
		'rightXpath': {rightXpath:getAbsXpath(event.target)}
	});
	chrome.storage.sync.set({
		'rightCoord': {X:event.pageX - window.pageXOffset,Y:event.pageY - window.pageYOffset}
	});
};