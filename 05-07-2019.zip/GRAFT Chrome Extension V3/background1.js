
    chrome.tabs.query({
        currentWindow: true,
        active: true
    }, function (tabs) {
        var updateProperties = {
            "active": true
        };
        chrome.tabs.update(tabs[0].id, updateProperties, function (tab) {

            chrome.tabs.executeScript(tab.id, {
                file: "content_script.js"
            }, function () {
                if (chrome.runtime.lastError) {
                    alert('Current page is blocking extension');
                    return;
                }
            });

        });
    });
// chrome.runtime.onConnect.addListener(function(devToolsConnection) {
//       // assign the listener function to a variable so we can remove it later
//     var devToolsListener = function(message, sender, sendResponse) {
//         // Inject a content script into the identified tab
//         chrome.tabs.executeScript(message.tabId,
//             { file: message.scriptToInject });            
//     }
    
//         // add the listener
//     devToolsConnection.onMessage.addListener(devToolsListener);
    
//     devToolsConnection.onDisconnect.addListener(function() {
//          devToolsConnection.onMessage.removeListener(devToolsListener);
//     });
// });