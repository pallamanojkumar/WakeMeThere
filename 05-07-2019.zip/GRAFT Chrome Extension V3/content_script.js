var addonlastElement = null;
var addonDrag = false;
var objectMap = {};
var wholeMap = {};
var isEditing = false;
var currentElement = null;
var currntXpath = "";
var cssSelector = "";
var state = "none";
var contextElement = null;
var iframeContent = null;
var iframeInfo = "";
var isExtesionClose = false;
var childToParent = "Child-to-Parent";
var parentToChild = "Parent-to-Child";
var sortOrder=childToParent;
var inspectorHeight=300;
var firstElementInspector=true;

var globalIgnoreAttributes = ["width", "height","maxlength","max","min","size"];
var xPath = {};
var cssPath = {};
var jqueryPath = {};
// var elements=[];
var attributeSplitter = "#attr-split#";

var lastHeight = 0;
var rootElement = null;
var decodeCharacters = {
    "&amp;": "&",
    "&lt;": "<",
    "&gt;": ">"
};

// var xpathParentElementCombinations=[];

var encodeCharacters = {
    "&": "&amp;",
    "<": "&lt;",
    ">;": "&gt;"
};


function mouseoutHandler(e) {
    jQuery(this).removeClass("addon-hover");
}

function mouseoverHandler(event) {
    if (addonDrag) return;
    if (jQuery(".addon-footer").length === 0) return;
    if (jQuery(".addon-footer").data("stop")) return;
    event.stopImmediatePropagation();
    event.preventDefault();
    event.stopPropagation();
    var t = 'target' in event ? event.target : event.srcElement;

    jQuery(this).addClass("addon-hover").parents().removeClass("addon-hover");
}




function getJquery(el) {
    if (iframeContent && iframeContent[0].ContentWindow && !(el instanceof iframeContent[0].ContentWindow.HTMLElement))
        return;
    else if (!iframeContent && (!el || !(el instanceof Element)))
        return;
    var firstElement = { element: el };
    var result = {};
    var isFirstElement = true;

    jqueryPath.counter = 0;
    jqueryPath.relativeSelectors = [];
    jqueryPath.indexBasedSelectors = [];
    jqueryPath.indexBasedSelector = '';
    while (el.nodeType === Node.ELEMENT_NODE) {
        jqueryPath.counter++;
        let textAttribute = '';
        
        let tempEle = iframeContent ? iframeContent.find(el) : jQuery(el);
        let eleText = getFirstTextNodeValue(tempEle);
        let trimmedEleText = '';
        if(eleText.includes("\n")){
            trimmedEleText=eleText.split("\n")[0];
            trimmedEleText=trimmedEleText.replace(/(\r)/gm,"").trim();
        }
        else{
            trimmedEleText=eleText.replace(/(\r\n|\n|\r)/gm, "").trim();
        }
        if (trimmedEleText.length > 0) {
            let encodedText = decodeHtmlSpecialCharacters(trimmedEleText);
            textAttribute = ":contains('" + escapeSpecialCharacters(encodedText) + "')";
        }

        let currentElement = { element: el, textValue: textAttribute };
        if (isFirstElement) {
            firstElement.textValue = textAttribute;
            currentElement = null;
            isFirstElement = false;
        } else {
            let classes = '';
            let relativePath = '';
            if (el.getAttribute("class") && el.getAttribute("class").trim().length) {
                classes = el.getAttribute("class").replace("addon-hover", " ").replace("  ", " ").trim().replace(/\s/g, ".");
                classes = "." + classes;
            }
            relativePath = el.nodeName.toLowerCase() + classes;
            jqueryPath.relativeSelectors.push(relativePath);
        }
        result = tryJQueryCombinations(firstElement, currentElement);
        if (result.foundUnique) {
            break;
        }
        el = el.parentNode;
    }
    if (result.foundUnique) {
        return result.path;
    }
    else {
        let selectedElementTagName = firstElement.element.nodeName.toLowerCase();
        let path = selectedElementTagName;
        if (jqueryPath.selectedElementIndex) {
            path = selectedElementTagName + ":nth-child(" + (jqueryPath.selectedElementIndex) + ")"
            if (checkUnique([path])) {
                return path;
            }
            jqueryPath.selectedEleAllCombinations.push(":nth-child(" + (jqueryPath.selectedElementIndex) + ")");
        }

        let attributesCombinationCount = jqueryPath.selectedEleAllCombinations.length;
        let pathCombinationCount = jqueryPath.indexBasedSelectors.length;
        let isUnique = false;
        for (let i = 0; i < pathCombinationCount; i++) {
            for (let j = 0; j < attributesCombinationCount; j++) {
                path = jqueryPath.indexBasedSelectors[i] + selectedElementTagName + jqueryPath.selectedEleAllCombinations[j];
                if (checkUnique([path])) {
                    isUnique = true;
                    break;
                }
            }
            if (isUnique)
                break;
        }
        return path;
    }
}

function tryJQueryCombinations(childElement, parentElement) {
    var selectedEleAllCombinations, parentEleAllCombinations, ignoreAttributes, additionalAttributes;
    var result = { path: '', foundUnique: false };
    var path = [];
    if (parentElement == null) {
        ignoreAttributes = ["id", ...globalIgnoreAttributes];
        additionalAttributes = [];

        if (childElement.textValue && childElement.textValue.length > 0) {
            additionalAttributes.push(childElement.textValue);
        }

        selectedEleAllCombinations = getJQueryAttributesCombination(childElement.element, ignoreAttributes, additionalAttributes);
        selectedEleAllCombinations.sort((item1, item2) => item1.split(attributeSplitter).length - item2.split(attributeSplitter).length);        
        selectedEleAllCombinations = selectedEleAllCombinations.map((item) => { return item.replace(/#attr-split#/g, "") });        
        jqueryPath.selectedEleAllCombinations = selectedEleAllCombinations;
        let count = selectedEleAllCombinations.length;
        for (let index = 0; index < count; index++) {
            path = [childElement.element.nodeName.toLowerCase() + selectedEleAllCombinations[index]];
            if (checkUnique(path)) {
                result.path = path[0];
                result.foundUnique = true;
                break;
            }
        }
        if(!result.foundUnique){
            result=trySiblingsCombinationsJQuery(childElement);
        }

        let previousSibilings = iframeContent ? iframeContent.find(childElement.element).prevAll() : $(childElement.element).prevAll();
        let nextSibilings = iframeContent ? iframeContent.find(childElement.element).nextAll() : $(childElement.element).nextAll();
            jqueryPath.selectedElementIndex = previousSibilings.length + 1;

        return result;
    }
    else {
        selectedEleAllCombinations = jqueryPath.selectedEleAllCombinations;
    }
    if(!result.foundUnique){
        result=trySiblingsCombinationsJQuery(childElement);
        if(result.foundUnique){
            return result;
        }
    }

    additionalAttributes = [];
    if (parentElement.textValue && parentElement.textValue.length > 0) {
        additionalAttributes.push(parentElement.textValue);
    }

    parentEleAllCombinations = getJQueryAttributesCombination(parentElement.element, globalIgnoreAttributes, additionalAttributes);
    parentEleAllCombinations.sort((item1, item2) => item1.split(attributeSplitter).length - item2.split(attributeSplitter).length);
    parentEleAllCombinations = parentEleAllCombinations.map((item) => { return item.replace(/#attr-split#/g, "") });
    var selectedElementCount = selectedEleAllCombinations.length;
    var parentElementCount = parentEleAllCombinations.length;
    var parentPath = '';
    let childPath = '';
    for (let i = 0; i < parentElementCount; i++) {
        parentPath = parentElement.element.nodeName.toLowerCase() + parentEleAllCombinations[i];
        for (let j = 0; j < selectedElementCount; j++) {
            childPath = childElement.element.nodeName.toLowerCase() + selectedEleAllCombinations[j];
            path = [parentPath + " " + childPath];
            if (checkUnique(path)) {
                if (jqueryPath.counter == 2)
                    result.path = parentPath + " > " + childPath;
                else
                    result.path = parentPath + "  " + childPath;

                result.foundUnique = true;
                break;
            }
        }
        if (result.foundUnique) {
            break;
        }
    }
    if(result.foundUnique){
        return result;
    }
    if(childElement.element.parentNode==parentElement.element){
        var parentElementPrecedingSiblingsJQuery=jQuery(parentElement.element).prev();
        var parentElementPrecedingSiblingsCombinationsJQuery=getJQueryElementsCombinations(parentElementPrecedingSiblingsJQuery);
        var parentElementBestCombinationJQuery=bestCombination(parentEleAllCombinations);
        var requiredParameters={
            referenceElementCombinations:[],
            selectedElementCombinations:[],
            selectedElement:{},
            relation:"",
            catalystElement:"",
            catalystElementBestCombination:"",
            isSelectedElementFirst:false
        };
        if(parentElementPrecedingSiblingsCombinationsJQuery.length>0)        {
            requiredParameters={
                referenceElementCombinations:parentElementPrecedingSiblingsCombinationsJQuery,
                selectedElementCombinations:selectedEleAllCombinations,
                selectedElement:childElement,
                relation:"{0} + {2} {1}",
                catalystElement:getNodeName(parentElement.element),
                catalystElementBestCombination:parentElementBestCombinationJQuery,
                isSelectedElementFirst:false
            };
            result=generateJQuerySelectorAndResult(requiredParameters);
            if(result.foundUnique){
                return result;
            }
        }
        var parentElementPrecedingSiblingsJQuery1=jQuery(parentElement.element).prevAll();
        var parentElementPrecedingSiblingsCombinationsJQuery1=getJQueryElementsCombinations(parentElementPrecedingSiblingsJQuery1);
        var parentElementBestCombinationJQuery=bestCombination(parentEleAllCombinations);
        requiredParameters={
            referenceElementCombinations:parentElementPrecedingSiblingsCombinationsJQuery1,
            selectedElementCombinations:selectedEleAllCombinations,
            selectedElement:childElement,
            relation:"{0} ~ {2} {1}",
            catalystElement:getNodeName(parentElement.element),
            catalystElementBestCombination:parentElementBestCombinationJQuery,
            isSelectedElementFirst:false
        };
        result=generateJQuerySelectorAndResult(requiredParameters);
        if(result.foundUnique){
            return result;
        }
        var parentElementFollowingSibling=jQuery(parentElement.element).next();
        var parentElementFollowingSiblingCombinationsJQuery=getJQueryElementsCombinations(parentElementFollowingSibling);
        var parentElementBestCombination=bestCombination(parentEleAllCombinations);
        if(parentElementFollowingSiblingCombinationsJQuery.length>0){
            requiredParameters={
                catalystElement:getNodeName(parentElement.element),
                catalystElementBestCombination:parentElementBestCombination,
                isSelectedElementFirst:false,
                referenceElementCombinations:parentElementFollowingSiblingCombinationsJQuery,
                relation:"{2}:has( + {0}) {1}" ,
                selectedElement:childElement,
                selectedElementCombinations:selectedEleAllCombinations
            };
            result=generateJQuerySelectorAndResult(requiredParameters);
            if(result.foundUnique){
                return result;
            }
        }
        
        var parentElementFollowingSibling1=jQuery(parentElement.element).nextAll();
        var parentElementFollowingSiblingCombinationsJQuery1=getJQueryElementsCombinations(parentElementFollowingSibling1);
        var parentElementBestCombination=bestCombination(parentEleAllCombinations);
        if(parentElementFollowingSiblingCombinationsJQuery1.length>0){
            requiredParameters={
                catalystElement:getNodeName(parentElement.element),
                catalystElementBestCombination:parentElementBestCombination,
                isSelectedElementFirst:false,
                referenceElementCombinations:parentElementFollowingSiblingCombinationsJQuery1,
                relation:"{2}:has( ~ {0}) {1}" ,
                selectedElement:childElement,
                selectedElementCombinations:selectedEleAllCombinations
            };
            result=generateJQuerySelectorAndResult(requiredParameters);
            if(result.foundUnique){
                return result;
            }
        }
        var parentBestCombination=bestCombination(parentEleAllCombinations);
        if(parentElementPrecedingSiblingsJQuery.children.length>0){
            var parentPrecedingSiblingChildren=parentElementPrecedingSiblingsJQuery.children;
            var parentPrecedingSiblingChildrenCombinations=getJQueryElementsCombinations(parentPrecedingSiblingChildren);
            var parentPrecedingSiblingBestCombination=bestCombination(parentElementPrecedingSiblingsCombinationsJQuery);
           if(parentPrecedingSiblingChildrenCombinations.length>0){
            requiredParameters={
                catalystElement:getNodeName(parentElementPrecedingSiblingsJQuery),
                catalystElementBestCombination:parentPrecedingSiblingBestCombination,
                referenceElementCombinations:parentPrecedingSiblingChildrenCombinations,
                relation:"{2}:has({0}) + {3} {1}",
                selectedElement:childElement,
                selectedElementCombinations:selectedEleAllCombinations,
                secondCatalyst:parentElement,
                secondCatalystBestCombination:parentBestCombination
            };
            result=generateJQuerySelectorAndResult(requiredParameters);
            if(result.foundUnique){
                return result;
            }
           }
        }
        if(parentElementFollowingSibling.children.length>0){
            var parentFollowingSiblingChildren=parentElementFollowingSibling.children;
            var parentFollowingSiblingChildrenCombinations=getJQueryElementsCombinations(parentFollowingSiblingChildren);
            var parentFollowingSiblingBestCombination=bestCombination(parentFollowingSiblingChildrenCombinations);
            if(parentFollowingSiblingChildrenCombinations.length>0){
                requiredParameters={
                    catalystElement:getNodeName(parentElementFollowingSibling),
                    catalystElementBestCombination:parentFollowingSiblingBestCombination,
                    referenceElementCombinations:parentFollowingSiblingChildrenCombinations,
                    relation:"{3} :has(+ {2}:has({0})) {1}",
                    selectedElement:childElement,
                    selectedElementCombinations:selectedEleAllCombinations,
                    secondCatalyst:parentElement,
                    secondCatalystBestCombination:parentBestCombination
                };
                result=generateJQuerySelectorAndResult(requiredParameters);
                if(result.foundUnique){
                    return result;
                }
            }
        }
        for(let i=0;i<parentElementPrecedingSiblingsJQuery1.length;i++){
            var children=parentElementPrecedingSiblingsJQuery1[i].children;
            var Catalyst1Combinations=parentElementPrecedingSiblingsCombinationsJQuery1.find(x=>x.key==parentElementPrecedingSiblingsJQuery1[i]).value;
            var catalyst1BestCombination=bestCombination(Catalyst1Combinations);
            var childrenCombinations=getJQueryElementsCombinations(children);
            if(childrenCombinations.length>0){
                requiredParameters={
                    catalystElement:getNodeName(parentElementPrecedingSiblingsJQuery1[i]),
                    catalystElementBestCombination:catalyst1BestCombination,
                    referenceElementCombinations:childrenCombinations,
                    relation:"{2}:has({0}) ~ {3} {1}",
                    secondCatalyst:parentElement,
                    secondCatalystBestCombination:parentBestCombination,
                    selectedElement:childElement,
                    selectedElementCombinations:selectedEleAllCombinations
                };
                result=generateJQuerySelectorAndResult(requiredParameters);
                if(result.foundUnique){
                    return result;
                }
            }
        }
        for(let i=0;i<parentElementFollowingSibling1.length;i++){
            var children=parentElementFollowingSibling1[i].children;            
            var Catalyst1Combinations=parentElementFollowingSiblingCombinationsJQuery1.find(x=>x.key==parentElementFollowingSibling1[i]).value;
            var catalyst1BestCombination=bestCombination(Catalyst1Combinations);
            var childrenCombinations=getJQueryElementsCombinations(children);
           if(childrenCombinations.length>0){
            requiredParameters={
                catalystElement:getNodeName(parentElementFollowingSibling1[i]),
                catalystElementBestCombination:catalyst1BestCombination,
                referenceElementCombinations:childrenCombinations,
                relation:"{3} :has(~ {2}:has({0})) {1}",
                secondCatalyst:parentElement,
                secondCatalystBestCombination:parentBestCombination,
                selectedElement:childElement,
                selectedElementCombinations:selectedEleAllCombinations
            };
            result=generateJQuerySelectorAndResult(requiredParameters);
            if(result.foundUnique){
                return result;
            }
           }
        }

    }
    if (jqueryPath.counter > 2) {
        //check for relative path
        for (let i = 0; i < parentElementCount; i++) {
            parentPath = parentElement.element.nodeName.toLowerCase() + parentEleAllCombinations[i];
            for (let j = 0; j < selectedElementCount; j++) {
                childPath = childElement.element.nodeName.toLowerCase() + selectedEleAllCombinations[j];
                path = [parentPath, ...jqueryPath.relativeSelectors, childPath];
                if (checkUnique(path)) {
                    result.path = path.join(" > ");
                    result.foundUnique = true;
                    break;
                }
            }
            if (result.foundUnique) {
                break;
            }
        }
    }
    if (result.foundUnique)
    return result;    


    if (!result.foundUnique) {
        let previousSibilings = iframeContent ? iframeContent.find(parentElement.element).prevAll() : $(parentElement.element).prevAll();
        let nextSibilings = iframeContent ? iframeContent.find(parentElement.element).nextAll() : $(parentElement.element).nextAll();

        if (previousSibilings.length > 0 || nextSibilings.length > 0) {
            jqueryPath.indexBasedSelector = parentElement.element.nodeName.toLowerCase() + ":nth-child(" + (previousSibilings.length + 1) + ") > " + jqueryPath.indexBasedSelector;
        }
        else {
            jqueryPath.indexBasedSelector = parentElement.element.nodeName.toLowerCase() + " > " + jqueryPath.indexBasedSelector;
        }
        jqueryPath.indexBasedSelectors.push(jqueryPath.indexBasedSelector);
    }
    return result;
}

function getNodeName(element){
    return element.nodeName.toLowerCase();
}

function trySiblingsCombinationsJQuery(selectedElement){
    var ignoreAttributes=[...globalIgnoreAttributes];
    var additionalAttributes=[];
    var result={
        path:"",
        foundUnique:false
    };
    var requiredParameters={
        referenceElementCombinations:{},
        selectedElementCombinations:{},
        selectedElement:{},
        relation:"",
        catalystElement:"",
        catalystElementBestCombination:"",
        isSelectedElementFirst:false
    };
    if(selectedElement.textValue && selectedElement.textValue.length>0){
        additionalAttributes.push(selectedElement.textValue);
    }
    var selectedEleAllCombinations=getJQueryAttributesCombination(selectedElement.element,ignoreAttributes,additionalAttributes);
    result= tryChildCombinationsJQuery(selectedElement);
    if(result.foundUnique){
        return result;
    }
    var prevSibling=jQuery(selectedElement.element).prev();    
    var immediatePreviousElement=getJQueryElementsCombinations(prevSibling);
   if(immediatePreviousElement.length>0){
    requiredParameters={
        referenceElementCombinations:immediatePreviousElement,
        selectedElementCombinations:selectedEleAllCombinations,
        selectedElement:selectedElement,
        relation:"{0} + {1}",
        catalystElement:"",
        catalystElementBestCombination:"",
        isSelectedElementFirst:false
    };
    result=generateJQuerySelectorAndResult(requiredParameters);
    if(result.foundUnique){
        return result;
    }
   }
    if(prevSibling.children.length>0)  {
        var precedingSiblingChildren=prevSibling.children;
        var precedingSiblingChildrencCombinations=getJQueryElementsCombinations(precedingSiblingChildren);
        var prevCatalystElementBestCombination=bestCombination(immediatePreviousElement);
        if(precedingSiblingChildrencCombinations.length>0){
            requiredParameters={
                catalystElement:getNodeName(prevSibling[0]),
                catalystElementBestCombination:prevCatalystElementBestCombination,
                referenceElementCombinations:precedingSiblingChildrencCombinations,
                relation:"$(\"{2}:has({0}) + {1})\")",
                selectedElement:selectedElement,
                selectedElementCombinations:selectedEleAllCombinations
            };
            result=generateJQuerySelectorAndResult(requiredParameters);
            if(result.foundUnique){
                return result;
            }
        }
    }
    var prevSiblingElements=jQuery(selectedElement.element).prevAll();
    var allPreviousSiblingElementsCombinations=getJQueryElementsCombinations(prevSiblingElements);    
    if(allPreviousSiblingElementsCombinations.length>0){
        requiredParameters={
            referenceElementCombinations:allPreviousSiblingElementsCombinations,
            selectedElementCombinations:selectedEleAllCombinations,
            selectedElement:selectedElement,
            relation:"{0} ~ {1}",
            catalystElement:"",
            catalystElementBestCombination:"",
            isSelectedElementFirst:false
        };
        result=generateJQuerySelectorAndResult(requiredParameters);
        if(result.foundUnique){
            return result;
        }
    }
    var nextSibling=jQuery(selectedElement.element).next();
    var immediateNextElement=getJQueryElementsCombinations(nextSibling);    
    if(immediateNextElement.length>0) {
        requiredParameters={
            referenceElementCombinations:immediateNextElement,
            selectedElementCombinations:selectedEleAllCombinations,
            selectedElement:selectedElement,
            relation:"{1}:has( + {0})",
            catalystElement:"",
            catalystElementBestCombination:"",
            isSelectedElementFirst:true
        };
        result=generateJQuerySelectorAndResult(requiredParameters);
        if(result.foundUnique){
            return result;
        }
    }
    if(nextSibling.children.length>0){
        var followingSiblingChildren=nextSibling.children;
        var followingSiblingChildrenCombinations=getJQueryElementsCombinations(followingSiblingChildren);
        var followingCatalystElementBestCOmbination=bestCombination(immediateNextElement);
        if(followingSiblingChildrenCombinations.length>0){
            requiredParameters={
                catalystElement:getNodeName(nextSibling[0]),
                catalystElementBestCombination:followingCatalystElementBestCOmbination,
                referenceElementCombinations:followingSiblingChildrenCombinations,
                relation:"{1}:has( + {2} {0})",
                selectedElement:selectedElement,
                selectedElementCombinations:selectedEleAllCombinations
            };
            result=generateJQuerySelectorAndResult(requiredParameters);
            if(result.foundUnique){
                return result;
            }
        }
    }
    for(let i=0;i<prevSiblingElements.length;i++){
        if(prevSiblingElements[i].children.length>0){
            var precedingSiblingChildElementsJQuery=prevSiblingElements[i].children;
            var precedingSiblingChildElementsCombinationsJQuery=getJQueryElementsCombinations(precedingSiblingChildElementsJQuery);
            var catalystElementCombinations=getJQueryElementsCombinations(prevSiblingElements[i]);
            var catalystElementBestCombination=bestCombination(catalystElementCombinations.value);
           if(precedingSiblingChildElementsCombinationsJQuery.length>0){
            requiredParameters={
                catalystElement:getNodeName(prevSiblingElements[i]),
                catalystElementBestCombination:catalystElementBestCombination,
                isSelectedElementFirst:false,
                referenceElementCombinations:precedingSiblingChildElementsCombinationsJQuery,
                relation:"$(\"{2}:has({0}) ~ {1})\")",
                selectedElement:selectedElement,
                selectedElementCombinations:selectedEleAllCombinations
            };
            result=generateJQuerySelectorAndResult(requiredParameters);
            if(result.foundUnique){
                return result;
            }
           }
        }
    }  
    var nextSiblingElements=jQuery(selectedElement.element).nextAll();
    var nextAllSiblingElementsCombinations=getJQueryElementsCombinations(nextSiblingElements);
    if(nextAllSiblingElementsCombinations.length>0){        
        requiredParameters={
            referenceElementCombinations:nextAllSiblingElementsCombinations,
            selectedElementCombinations:selectedEleAllCombinations,
            selectedElement:selectedElement,
            relation:"{1}:has( ~ {0})",
            catalystElement:{},
            catalystElementBestCombination:""
        };
        result= generateJQuerySelectorAndResult(requiredParameters);    
        if(result.foundUnique){
            return result;
        }
    }
    for(let i=0;i<nextSiblingElements.length;i++){
        if(nextSiblingElements[i].children.length>0){
            var followingSiblingChildElementsJQuery=nextSiblingElements[i].children;
            var followingSiblingChildElementsCombinationsJQuery=getJQueryElementsCombinations(followingSiblingChildElementsJQuery);
            var catalystElementCombinations=getJQueryElementsCombinations(nextSiblingElements[i]);
            var catalystElementBestCombination=bestCombination(catalystElementCombinations.value);
            if(followingSiblingChildElementsCombinationsJQuery.length>0){             
                requiredParameters={
                    catalystElement:getNodeName(nextSiblingElements[i]),
                    catalystElementBestCombination:catalystElementBestCombination,
                    isSelectedElementFirst:false,
                    referenceElementCombinations:followingSiblingChildElementsCombinationsJQuery,
                    relation:"{1}:has( ~ {2} {0})",
                    selectedElement:selectedElement,
                    selectedElementCombinations:selectedEleAllCombinations
                };
                    result=generateJQuerySelectorAndResult(requiredParameters);
                    if(result.foundUnique){
                        return result;
                    }   
            }
        }
    }
    return result;
}

function tryChildCombinationsJQuery(selectedElement,actualElement={}){
    var additionalAttributes=[];
    if(selectedElement.textValue && selectedElement.textValue.length>0){
        additionalAttributes.push(selectedElement.textValue);
    }
    var isActualSelectedElementEmpty=Object.entries(actualElement).length === 0 && actualElement.constructor === Object;
    var selectedEleAllCombinations=isActualSelectedElementEmpty?getJQueryAttributesCombination(selectedElement.element,globalIgnoreAttributes,additionalAttributes):actualElement.value;
    var element=isActualSelectedElementEmpty?{key:selectedElement,value:selectedEleAllCombinations}:actualElement;
    var childElements=isActualSelectedElementEmpty?jQuery(selectedElement.element).children():selectedElement.children;
    var childElementCombinations=getJQueryElementsCombinations(childElements);    
    var result={
        path:"",
        foundUnique:false
    };
    if(childElementCombinations.length==0){
        return result;
    }
    var requiredParameters={
        referenceElementCombinations:childElementCombinations,
        selectedElementCombinations:selectedEleAllCombinations,
        selectedElement:element,
        relation:"{1}:has({0})",
        catalystElement:"",
        catalystBestCombination:"",
        isSelectedElementFirst:true
    };
    result=generateJQuerySelectorAndResult(requiredParameters);
    if(result.foundUnique){
        return result;
    }
    for(let i=0;i<childElements.length;i++){
        result=tryChildCombinationsJQuery(childElements[i],element);
        if(result.foundUnique){
            break;
        }
    }
    return result;
}

function getJQueryElementsCombinations(elements){
    var elementCombinations=[];
    for(let i=0;i<elements.length;i++){
        elementCombinations.push({
            key:elements[i],
            value:getJQueryAttributesCombination(elements[i],globalIgnoreAttributes)
        });
        if(typeof elements[i]=='undefined'){
            elementCombinations.pop();
        }
        let tempEle=jQuery(elements[i]);
        if(tempEle.children().length==0 && tempEle.text().length>0){
            let value=elementCombinations.find(x=>x.key==elements[i]).value;
            elementCombinations.find(x=>x.key==elements[i]).value=value.concat(":contains(\"" + tempEle.text().trim() + "\")");
        }
    }
    return elementCombinations;
}

function getJQueryAttributesCombination(element, ignoreAttributes = [], additionalAttributes = []) {
    let attributes = [];
    var isCssAlreadyExitsInIgnoreAttributes = false;
    var isStyleAlreadyExitsInIgnoreAttributes = false;

    if (!element) {
        return attributes;
    }

    ignoreAttributes = [...ignoreAttributes];

    if (ignoreAttributes.indexOf("class") > -1) {
        isCssAlreadyExitsInIgnoreAttributes = true;
    } else {
        ignoreAttributes.push("class");
    }

    if (ignoreAttributes.indexOf("style") > -1) {
        isStyleAlreadyExitsInIgnoreAttributes = true;
    } else {
        ignoreAttributes.push("style");
    }

    if (ignoreAttributes.indexOf("id") === -1 && element.getAttribute("id") && element.getAttribute("id").trim().length) {
        attributes.push("#" + element.getAttribute("id").replace(':', '\\:').replace(".", "\\.").replace("#", "\\#"));
        ignoreAttributes.push("id");
    }

    if (ignoreAttributes.indexOf("name") == -1 && element.getAttribute("name") && element.getAttribute("name").trim().length) {
        attributes.push(`[name='${escapeSpecialCharacters(element.getAttribute("name"))}']`);
        ignoreAttributes.push("name");
    }

    attributes = [...attributes, ...additionalAttributes];

    [...element.attributes].forEach((attribute) => {
        if (attribute.name && attribute.value && attribute.value.trim().length > 0 && ignoreAttributes.indexOf(attribute.name) === -1)
            attributes.push(`[${attribute.name}='${escapeSpecialCharacters(attribute.value)}']`);
    });

    if (isCssAlreadyExitsInIgnoreAttributes === false && element.getAttribute("class") && element.getAttribute("class").trim().length) {
        let classes = element.getAttribute("class").replace("addon-hover", " ").replace("  ", " ").trim();
        attributes.push(`[class='${classes}']`);
    }

    if (isStyleAlreadyExitsInIgnoreAttributes === false && element.getAttribute("style") && element.getAttribute("style").trim().length) {
        attributes.push(`[style='${escapeSpecialCharacters(element.getAttribute("style"))}']`);
    }
    return getCombinations(attributes, attributeSplitter);
}

function generateJQuerySelectorAndResult(requiredParameters={}){
    var {referenceElementCombinations,selectedElementCombinations,selectedElement,relation,catalystElement="", catalystElementBestCombination="",secondCatalyst={},secondCatalystBestCombination=""}=requiredParameters;
    var result={
        path:"",
        foundUnique:false
    };
    var childPath="";
    var parentPath="";
    var nodeName=selectedElement.element!=null?selectedElement.element.nodeName.toLowerCase():selectedElement.key.element.nodeName.toLowerCase();
    var isCatalystEmpty=Object.entries(catalystElement).length === 0 && catalystElement.constructor === Object;
    var isSecondCatalystEmpty=Object.entries(secondCatalyst).length === 0 && secondCatalyst.constructor === Object;    
    var catalystNode=catalystElement;
    var secondCatalystNode="";
    if(!isCatalystEmpty){    
        relation=relation.replace("{2}",catalystNode+catalystElementBestCombination);
    }
    if(!isSecondCatalystEmpty){
        if(secondCatalyst.element!=null){
            secondCatalystNode=secondCatalyst.element.nodeName.toLowerCase();
        }
        else{
            secondCatalystNode=secondCatalyst.nodeName.toLowerCase();
        }
        relation=relation.replace("{3}",secondCatalystNode+secondCatalystBestCombination);
    }
    for(let i=0;i<referenceElementCombinations.length;i++){
        for(let j=0;j<referenceElementCombinations[i].value.length;j++){
            childPath=referenceElementCombinations[i].key.nodeName.toLowerCase()+referenceElementCombinations[i].value[j];
            if(selectedElementCombinations.length>0){
                for(let k=0;k<selectedElementCombinations.length;k++){
                    parentPath=nodeName+selectedElementCombinations[k];
                    path=[relation.replace("{0}",childPath).replace("{1}",parentPath)];                        
                    if(checkUnique(path)){
                        result.path=relation.replace("{0}",childPath).replace("{1}",parentPath);
                        result.foundUnique=true;
                        return result;
                    }
                }
            }
            else{
                path=[relation.replace("{0}",childPath).replace("{1}",nodeName)];
                if(checkUnique(path)){
                    result.path=relation.replace("{0}",childPath).replace("{1}",nodeName);
                    result.foundUnique=true;
                    return result;
                }
            }
        }
    }
    return result;
}


function getXpath2(el) {
    if (iframeContent && iframeContent[0].ContentWindow && !(el instanceof iframeContent[0].ContentWindow.HTMLElement))
        return;
    else if (!iframeContent && (!el || !(el instanceof Element)))
        return;

    var path = [];

    while (el.nodeType === Node.ELEMENT_NODE) {
        var selector2 = el.nodeName.toLowerCase();
        var jquerySelectorTemp = selector2;
        var tempEle = iframeContent ? iframeContent.find(el) : jQuery(el);
        //this below line remove the unsupported charaters from selector
        jquerySelectorTemp = jquerySelectorTemp.replace(/\[@/g, "[");

        var previousSibilings = tempEle.prevAll(jquerySelectorTemp);
        var nextSibilings = tempEle.nextAll(jquerySelectorTemp);

        if (previousSibilings.length > 0 || nextSibilings.length > 0)
            selector2 += "[" + (previousSibilings.length + 1) + "]";

        path.unshift(selector2);
        el = el.parentNode
        if (checkUniqueXpath(path)) {
            break;
        }
    }
    return "//" + path.join("/");
}

function getXpath(el) {
    if (iframeContent && iframeContent[0].ContentWindow && !(el instanceof iframeContent[0].ContentWindow.HTMLElement))
        return;
    else if (!iframeContent && (!el || !(el instanceof Element)))
        return;

    var firstElement = { element: el };
    var result = {};
    xPath.counter = 0;
    var isFirstElement = true;
    while (el.nodeType === Node.ELEMENT_NODE) {
        xPath.counter++;
        let textAttribute = '';
        
        
        let tempEle = iframeContent ? iframeContent.find(el) : jQuery(el);
        let eleText = getFirstTextNodeValue(tempEle);
        let trimmedEleText = '';
        if(eleText.includes("\n")){
            trimmedEleText=eleText.split("\n")[0];
            trimmedEleText=trimmedEleText.replace(/(\r)/gm,"").trim();
        }
        else{
            trimmedEleText=eleText.replace(/(\r\n|\n|\r)/gm, "").trim();
        }
        if (trimmedEleText.length > 0) {
            let encodedText = trimmedEleText;
            encodedText = decodeHtmlSpecialCharacters(encodedText);

            if (trimmedEleText === eleText) {
                if (encodedText.includes("'"))
                    textAttribute = "[text()=\"" + encodedText + "\"]"
                else
                    textAttribute = "[text()='" + encodedText + "']"

            } else {
                if (encodedText.includes("'"))
                    textAttribute = "[contains(text(),\"" + encodedText + "\")]"
                else
                    textAttribute = "[contains(text(),'" + encodedText + "')]"
            }
        }

        let currentElement = { element: el, textValue: textAttribute };
        if (isFirstElement) {
            firstElement.textValue = textAttribute;
            currentElement = null;
            isFirstElement = false;
        }
        result = tryXpathCombinations(firstElement, currentElement);
        if (result.foundUnique) {
            break;
        }
        // elements.push(el);
        el = el.parentNode;
    }
    if (result.foundUnique) {
        currntXpath = result.path;
    }
    else {
        currntXpath = "//" + firstElement.element.tagName.toLowerCase();
        if (Array.isArray(xPath.selectedEleAllCombinations) && xPath.selectedEleAllCombinations.length)
            currntXpath += xPath.selectedEleAllCombinations.reduce((a, b) => a.length > b.length ? a : b, '');

        let elements = getElementsByXPath(currntXpath);
        let counter = elements.length;
        for (let index = 0; index < counter; index++) {
            if (firstElement.element.isSameNode(elements[index])) {
                currntXpath = `(${currntXpath})[${index + 1}]`;
                break;
            }
        }
    }
}

function tryXpathCombinations(childElement, parentElement) {
    var selectedEleAllCombinations, parentEleAllCombinations, ignoreAttributes, additionalAttributes;
    var result = { path: '', foundUnique: false };
    var path = [];

    if (parentElement == null) {
        ignoreAttributes = ["id", ...globalIgnoreAttributes];
        additionalAttributes = [];

        if (childElement.textValue && childElement.textValue.length > 0)
            additionalAttributes.push(childElement.textValue);

        selectedEleAllCombinations = getXpathAttributesCombination(childElement.element, ignoreAttributes, additionalAttributes);
        selectedEleAllCombinations.sort((item1, item2) => item1.split("[").length - item2.split("[").length);
        xPath.selectedEleAllCombinations = selectedEleAllCombinations;

        let count = selectedEleAllCombinations.length;
        for (let index = 0; index < count; index++) {
            path = [childElement.element.nodeName.toLowerCase() + selectedEleAllCombinations[index]];
            if (checkUniqueXpath(path)) {
                result.path = '//' + path[0];
                result.foundUnique = true;
                break;
            }
        }
        if(!result.foundUnique){
            result=trySiblingsCombinations(childElement);        
        }
        return result;
    }
    else {
        selectedEleAllCombinations = xPath.selectedEleAllCombinations;
    }
    if(!result.foundUnique){
        result=trySiblingsCombinations(childElement);   
        if(result.foundUnique)     {
            return result;
        }
    }
    additionalAttributes = [];
    if (parentElement.textValue && parentElement.textValue.length > 0)
        additionalAttributes.push(parentElement.textValue);
    parentEleAllCombinations = getXpathAttributesCombination(parentElement.element, globalIgnoreAttributes, additionalAttributes);
    parentEleAllCombinations.sort((item1, item2) => item1.split("[").length - item2.split("[").length);
    var selectedElementCount = selectedEleAllCombinations.length;
    var parentElementCount = parentEleAllCombinations.length;
    var parentPath = '';
    var childPath = '';
    for (let i = 0; i < parentElementCount; i++) {
        parentPath = parentElement.element.nodeName.toLowerCase() + parentEleAllCombinations[i];
            for (let j = 0; j < selectedElementCount; j++) {
                childPath = childElement.element.nodeName.toLowerCase() + selectedEleAllCombinations[j];            
                path = [parentPath + '//' + childPath];
                if (checkUniqueXpath(path)) {
                    if (xPath.counter == 2)
                        result.path = '//' + parentPath + "/" + childPath;
                    else
                        result.path = '//' + parentPath + "//" + childPath;
                    result.foundUnique = true;
                    break;
                }
            }
        if (result.foundUnique)
            break;
    }
    if(result.foundUnique){
        return result;
    }
     if(childElement.element.parentNode==parentElement.element){
         var parentElementPrecedingSiblings=jQuery(parentElement.element).prevAll();
         var parentElementPrecedingSiblingsCombinations=getElementsCombinations(parentElementPrecedingSiblings);
         var parentElementBestCombination=bestCombination(parentEleAllCombinations);
         result=generateXpathAndResult(parentElementPrecedingSiblingsCombinations,selectedEleAllCombinations,childElement,"/following-sibling::child",parentElement,parentElementBestCombination);
         if(result.foundUnique){
             return result;
         }
         var parentElementFollowingSiblings=jQuery(parentElement.element).nextAll();
         var parentElementFollowingSiblingsCombinations=getElementsCombinations(parentElementFollowingSiblings);
         result=generateXpathAndResult(parentElementFollowingSiblingsCombinations,selectedEleAllCombinations,childElement,"/preceding-sibling::child",parentElement,parentElementBestCombination);
         if(result.foundUnique){
             return result;
         }
         for(let i=0;i<parentElementPrecedingSiblings.length;i++){
             var parentPrecedingSiblingsChildren=parentElementPrecedingSiblings[i].children;
             var parentPrecedingSiblingsCombinations=parentElementPrecedingSiblingsCombinations.find(x=>x.key==parentElementPrecedingSiblings[i]).value;
             var parentPrecedingSiblingBestCombination=bestCombination(parentPrecedingSiblingsCombinations)
             var parentPrecedingSiblingsChildrenCombinations=getElementsCombinations(parentPrecedingSiblingsChildren);
             result=generateXpathAndResult(parentPrecedingSiblingsChildrenCombinations,selectedEleAllCombinations,childElement,"/parent::following-sibling::/child",parentElementPrecedingSiblings[i],parentPrecedingSiblingBestCombination,parentElement,parentElementBestCombination);
             if(result.foundUnique){
                 return result;
             }
         }
         for(let i=0;i<parentElementFollowingSiblings.length;i++){
            var parentFollowingSiblingsChildren=parentElementFollowingSiblings[i].children;
            var parentFollowingSiblingsCombinations=parentElementFollowingSiblingsCombinations.find(x=>x.key==parentElementFollowingSiblings[i]).value;
            var parentFollowingSiblingBestCombination=bestCombination(parentFollowingSiblingsCombinations)
            var parentFollowingSiblingsChildrenCombinations=getElementsCombinations(parentFollowingSiblingsChildren);
            result=generateXpathAndResult(parentFollowingSiblingsChildrenCombinations,selectedEleAllCombinations,childElement,"/parent::preceding-sibling::/child",parentElementFollowingSiblings[i],parentFollowingSiblingBestCombination,parentElement,parentElementBestCombination);
            if(result.foundUnique){
                return result;
            }
        }
    }
    return result;
}

function getXpathAttributesCombination(element, ignoreAttributes = [], additionalAttributes = []) {
    var attributes = [];
    var isCssAlreadyExitsInIgnoreAttributes = false;
    var isStyleAlreadyExitsInIgnoreAttributes = false;

    if (!element)
        return attributes;

    ignoreAttributes = [...ignoreAttributes];

    if (ignoreAttributes.indexOf("class") > -1) {
        isCssAlreadyExitsInIgnoreAttributes = true;
    } else {
        ignoreAttributes.push("class");
    }

    if (ignoreAttributes.indexOf("style") > -1) {
        isStyleAlreadyExitsInIgnoreAttributes = true;
    } else {
        ignoreAttributes.push("style");
    }

    if (ignoreAttributes.indexOf("id") === -1 && element.getAttribute("id") && element.getAttribute("id").trim().length) {
        attributes.push(`[@id='${element.getAttribute("id").replace(':', '\\:')}']`);
        ignoreAttributes.push("id");
    }

    if (ignoreAttributes.indexOf("name") === -1 && element.getAttribute("name") && element.getAttribute("name").trim().length) {
        if (element.getAttribute("name").includes("'"))
            attributes.push(`[@name="${element.getAttribute("name")}"]`);
        else
            attributes.push(`[@name='${element.getAttribute("name")}']`);


        ignoreAttributes.push("name");
    }

    attributes = [...attributes, ...additionalAttributes];

    [...element.attributes].forEach((attribute) => {
        if (attribute.name && attribute.value && attribute.value.trim().length > 0 && ignoreAttributes.indexOf(attribute.name) === -1) {
            if (attribute.value.includes("'"))
                attributes.push(`[@${attribute.name}="${attribute.value}"]`);
            else
                attributes.push(`[@${attribute.name}='${attribute.value}']`);
        }

    });

    if (isCssAlreadyExitsInIgnoreAttributes === false && element.getAttribute("class") && element.getAttribute("class").trim().length) {
        let classes = element.getAttribute("class").replace("addon-hover", " ").replace(" ", " ").trim();
        attributes.push(`[@class='${classes}']`);
    }

    if (isStyleAlreadyExitsInIgnoreAttributes === false && element.getAttribute("style") && element.getAttribute("style").trim().length) {
        if (element.getAttribute("style").includes("'"))
            attributes.push(`[@style="${element.getAttribute("style")}"]`);
        else
            attributes.push(`[@style='${element.getAttribute("style")}']`);


    }

    return getCombinations(attributes, '');
}

function trySiblingsCombinations(selectedElement){
    var ignoreAttributes=[...globalIgnoreAttributes];
    var additionalAttributes=[];
    if(selectedElement.textValue && selectedElement.textValue.length>0){
        additionalAttributes.push(selectedElement.textValue);
    }
    var selectedEleAllCombinations=getXpathAttributesCombination(selectedElement.element,ignoreAttributes,additionalAttributes);
    var prevSiblingElements=jQuery(selectedElement.element).prevAll();
    var prevSiblingElementsCombinations=getElementsCombinations(prevSiblingElements);
    var result={
        path:"",
        foundUnique:false
    };
    result=tryChildElementCombinations(selectedElement);
    if(result.foundUnique){
        return result;
    }
    result=generateXpathAndResult(prevSiblingElementsCombinations,selectedEleAllCombinations,selectedElement,"/following-sibling::");
    if(result.foundUnique){
        return result;
    }
    var nextSiblingsElements=jQuery(selectedElement.element).nextAll();
    var nextSiblingsElementsCombinations=getElementsCombinations(nextSiblingsElements);
    result=generateXpathAndResult(nextSiblingsElementsCombinations,selectedEleAllCombinations,selectedElement,"/preceding-sibling::");
    if(result.foundUnique){
        return result;
    }
    for(let i=0;i<nextSiblingsElements.length;i++){
        if(nextSiblingsElements[i].children.length>0){
            var followingSiblingChildElements=nextSiblingsElements[i].children;
            var followingSiblingChildElementsCombinations=getElementsCombinations(followingSiblingChildElements);
            var catalystElementCombinations=getElementsCombinations(nextSiblingsElements[i]);
            var catalystElementBestCombination=bestCombination(catalystElementCombinations.value);
            result=generateXpathAndResult(followingSiblingChildElementsCombinations,selectedEleAllCombinations,selectedElement,"/preceding-sibling::parent",nextSiblingsElements[i],catalystElementBestCombination);
            if(result.foundUnique){
                return result;
            }
        }
    }
    for(let i=0;i<prevSiblingElements.length;i++){
        if(prevSiblingElements[i].children.length>0){
            var precedingSiblingChildElements=prevSiblingElements[i].children;
            var precedingSiblingChildElementsCombinations=getElementsCombinations(precedingSiblingChildElements);
            var catalystElementCombinations=getElementsCombinations(prevSiblingElements[i]);
            var catalystElementBestCombination=bestCombination(catalystElementCombinations.value);
            result=generateXpathAndResult(precedingSiblingChildElementsCombinations,selectedEleAllCombinations,selectedElement,"/following-sibling::parent",prevSiblingElements[i],catalystElementBestCombination);
            if(result.foundUnique){
                return result;
            }
        }
    }
    return result;
}

function bestCombination(xpathElementCombinations){
    var maxLength=0;
    var bestCombination="";
    if(xpathElementCombinations!=null && xpathElementCombinations.length>0){
        for(let i=0;i<xpathElementCombinations.length;i++){
            if(xpathElementCombinations[i].length>maxLength){
                maxLength=xpathElementCombinations[i].length;
                bestCombination=xpathElementCombinations[i];
            }
        }
    }
    return bestCombination;
}

function generateXpathAndResult(referenceElementCombinations,selectedElementCombinations,selectedElement,relation,catalystElement={},catalystBestCombination="",otherCatalyst={},otherCatalystBestCombination=""){
    var result={
        path:"",
        foundUnique:false
    };
    var nodeName=selectedElement.element!=null?selectedElement.element.nodeName.toLowerCase():selectedElement.key.element.nodeName.toLowerCase();    
    var isCatalystEmpty=Object.entries(catalystElement).length === 0 && catalystElement.constructor === Object;
    var catalystNode="";
    if(!isCatalystEmpty){
        if(catalystElement.element!=null){
            catalystNode=catalystElement.element.nodeName.toLowerCase();
        }
        else{
            catalystNode=catalystElement.nodeName.toLowerCase();
        }
    }
    if(catalystNode.length>0){
        if(relation.includes("parent")){
            if(relation.includes("child")){
                if(relation.includes("preceding-sibling")){
                    relation="/parent::"+catalystNode+catalystBestCombination+"/preceding-sibling::"+otherCatalyst.element.nodeName.toLowerCase()+"/child::";
                }
                else if(relation.includes("following-sibling")){
                    relation="/parent::"+catalystNode+catalystBestCombination+"/following-sibling::"+otherCatalyst.element.nodeName.toLowerCase()+"/child::";
                }
            }
            else if(relation.includes("following-sibling")){
                relation="/parent::"+catalystNode+catalystBestCombination+"/following-sibling::";
            }
            else if(relation.includes("preceding-sibling")){
                relation="/parent::"+catalystNode+catalystBestCombination+"/preceding-sibling::";
            }
        }
        else if(relation.includes("child")){
            if(relation.includes("following-sibling")){
                relation="/following-sibling::"+catalystNode+catalystBestCombination+"/child::";
            }
            else if(relation.includes("preceding-sibling")){
                relation="/preceding-sibling::"+catalystNode+catalystBestCombination+"/child::";
            }
        }
    }
    for(let i=0;i<referenceElementCombinations.length;i++){
        for(let j=0;j<referenceElementCombinations[i].value.length;j++){
            childPath=referenceElementCombinations[i].key.nodeName.toLowerCase()+referenceElementCombinations[i].value[j];
            if(selectedElementCombinations.length>0){
                for(let k=0;k<selectedElementCombinations.length;k++){
                    parentPath=nodeName+selectedElementCombinations[k];
                    path=[childPath+relation+parentPath];
                    if(checkUniqueXpath(path)){
                        result.path='//'+childPath+relation+parentPath;
                        result.foundUnique=true;
                        return result;
                    }
                }
            }
            else{
                path=[childPath+relation+nodeName];
                if(checkUniqueXpath(path)){
                    result.path="//"+childPath+relation+nodeName;
                    result.foundUnique=true;
                    return result;
                }
            }
        }
    }
    return result;
}

function tryChildElementCombinations(selectedElement,actualSelectedElement={}){
    var ignoreAttributes=[...globalIgnoreAttributes];
    var additionalAttributes=[];
    if(selectedElement.textValue && selectedElement.textValue.length>0){
        additionalAttributes.push(selectedElement.textValue);
    }
    var isActualSelectedElementEmpty=Object.entries(actualSelectedElement).length === 0 && actualSelectedElement.constructor === Object;
    var selectedEleAllCombinations=isActualSelectedElementEmpty?getXpathAttributesCombination(selectedElement.element,ignoreAttributes,additionalAttributes):actualSelectedElement.value;
    var element=isActualSelectedElementEmpty?{key:selectedElement,value:selectedEleAllCombinations}:actualSelectedElement;
    var childElements=Object.entries(actualSelectedElement).length === 0 && actualSelectedElement.constructor === Object?jQuery(selectedElement.element).children():selectedElement.children;
    var childElementCombinations=getElementsCombinations(childElements);
    var result={
        path:"",
        foundUnique:false
    };
    var relation=isActualSelectedElementEmpty?"/parent::":"/ancestor::";
    
    result=generateXpathAndResult(childElementCombinations,selectedEleAllCombinations,element,relation);
    if(result.foundUnique){
        return result;
    }    
    for(let i=0;i<childElements.length;i++){
        result=tryChildElementCombinations(childElements[i],element);
        if(result.foundUnique){
            break;
        }
    }
    return result;
}

function getElementsCombinations(elements){
    var elementCombinations=[];
    for(let i=0;i<elements.length;i++){
        elementCombinations.push({
            key:elements[i],
            value:getXpathAttributesCombination(elements[i],globalIgnoreAttributes)
        });
        let tempEle=jQuery(elements[i]);
        if(tempEle.children().length==0 && tempEle.text().length>0){
            let value=elementCombinations.find(x=>x.key==elements[i]).value;
            elementCombinations.find(x=>x.key==elements[i]).value=value.concat("[text()=\"" + tempEle.text().trim() + "\"]");
        }
    }
    return elementCombinations;
}

function getCssSelector(el) {
    if (iframeContent && iframeContent[0].ContentWindow && !(el instanceof iframeContent[0].ContentWindow.HTMLElement))
        return;
    else if (!iframeContent && (!el || !(el instanceof Element)))
        return;

    var result = {};
    var firstElement = el;
    var isFirstElement = true;

    cssPath.counter = 0;
    cssPath.relativeSelectors = [];
    cssPath.indexBasedSelectors = [];
    cssPath.indexBasedSelector = '';
    while (el.nodeType === Node.ELEMENT_NODE) {
        cssPath.counter++;
        let currentElement = el;
        if (isFirstElement) {
            currentElement = null;
            isFirstElement = false;
        } else {
            let classes = '';
            let relativePath = '';
            if (el.getAttribute("class") && el.getAttribute("class").trim().length) {
                classes = el.getAttribute("class").replace("addon-hover", " ").replace("  ", " ").trim().replace(/\s/g, ".");
                classes = "." + classes;
            }
            relativePath = el.nodeName.toLowerCase() + classes;
            cssPath.relativeSelectors.push(relativePath);
        }
        result = tryCssCombinations(firstElement, currentElement);
        if (result.foundUnique) {
            break;
        }
        el = el.parentNode;
    }

    if (result.foundUnique) {
        cssSelector = result.path;
    }
    else {
        let selectedElementTagName = firstElement.nodeName.toLowerCase();
        let path = selectedElementTagName;

        if (cssPath.selectedElementIndex) {
            path = selectedElementTagName + ":nth-child(" + (cssPath.selectedElementIndex) + ")"
            if (checkCssUnique([path])) {
                cssSelector = path;
                return;
            }
            cssPath.selectedEleAllCombinations.push(":nth-child(" + (cssPath.selectedElementIndex) + ")");
        }

        let attributesCombinationCount = cssPath.selectedEleAllCombinations.length;
        let pathCombinationCount = cssPath.indexBasedSelectors.length;
        let isUnique = false;
        for (let i = 0; i < pathCombinationCount; i++) {
            for (let j = 0; j < attributesCombinationCount; j++) {
                path = cssPath.indexBasedSelectors[i] + selectedElementTagName + cssPath.selectedEleAllCombinations[j];
                if (checkCssUnique([path])) {
                    isUnique = true;
                    break;
                }
            }
            if (isUnique)
                break;
        }
        cssSelector = path;
        return;
    }
}

function tryCssCombinations(childElement, parentElement) {
    var selectedEleAllCombinations, parentEleAllCombinations, ignoreAttributes;
    var result = { path: '', foundUnique: false };
    var path = [];
    if (parentElement == null) {
        ignoreAttributes = ["id", ...globalIgnoreAttributes];

        selectedEleAllCombinations = getCssAttibutesCombination(childElement, ignoreAttributes);
        selectedEleAllCombinations.sort((item1, item2) => item1.split(attributeSplitter).length - item2.split(attributeSplitter).length);
        selectedEleAllCombinations = selectedEleAllCombinations.map((item) => { return item.replace(/#attr-split#/g, "") });        
        cssPath.selectedEleAllCombinations = selectedEleAllCombinations;

        let count = selectedEleAllCombinations.length;
        for (let index = 0; index < count; index++) {
            path = [childElement.nodeName.toLowerCase() + selectedEleAllCombinations[index]];
            if (checkCssUnique(path)) {
                result.path = path[0];
                result.foundUnique = true;
                break;
            }
        }
        if(!result.foundUnique){
            result=trySiblingsCombinationsCSS(childElement);
        }

        let previousSibilings = iframeContent ? iframeContent.find(childElement).prevAll() : $(childElement).prevAll();
        let nextSibilings = iframeContent ? iframeContent.find(childElement).nextAll() : $(childElement).nextAll();

        //if (previousSibilings.length > 0 || nextSibilings.length > 0)
            cssPath.selectedElementIndex = previousSibilings.length + 1;

        return result;
    }
    else {
        selectedEleAllCombinations = cssPath.selectedEleAllCombinations;
    }
    if(!result.foundUnique){
        result=trySiblingsCombinationsCSS(childElement);
        if(result.foundUnique){
            return result;
        }
    }

    parentEleAllCombinations = getCssAttibutesCombination(parentElement, globalIgnoreAttributes);
    parentEleAllCombinations.sort((item1, item2) => item1.split(attributeSplitter).length - item2.split(attributeSplitter).length);
    parentEleAllCombinations = parentEleAllCombinations.map((item) => { return item.replace(/#attr-split#/g, "") });
    var selectedElementCount = selectedEleAllCombinations.length;
    var parentElementCount = parentEleAllCombinations.length;
    var parentPath = '';
    var childPath = '';
    for (let i = 0; i < parentElementCount; i++) {
        parentPath = parentElement.nodeName.toLowerCase() + parentEleAllCombinations[i];
        for (let j = 0; j < selectedElementCount; j++) {
            childPath = childElement.nodeName.toLowerCase() + selectedEleAllCombinations[j];
            path = [parentPath + " " + childPath];
            if (checkCssUnique(path)) {
                if (cssPath.counter == 2)
                    result.path = parentPath + " > " + childPath;
                else
                    result.path = parentPath + "  " + childPath;

                result.foundUnique = true;
                break;
            }
        }
        if (result.foundUnique) {
            break;
        }
    }

    if (result.foundUnique)
        return result;

    if (cssPath.counter > 2) {
        //check for relative path
        for (let i = 0; i < parentElementCount; i++) {
            parentPath = parentElement.nodeName.toLowerCase() + parentEleAllCombinations[i];
            for (let j = 0; j < selectedElementCount; j++) {
                childPath = childElement.nodeName.toLowerCase() + selectedEleAllCombinations[j];
                path = [parentPath, ...cssPath.relativeSelectors, childPath];
                if (checkCssUnique(path)) {
                    result.path = path.join(" > ");
                    result.foundUnique = true;
                    break;
                }
            }
            if (result.foundUnique) {
                break;
            }
        }
    }

    if (!result.foundUnique) {
        let previousSibilings = iframeContent ? iframeContent.find(parentElement).prevAll() : $(parentElement).prevAll();
        let nextSibilings = iframeContent ? iframeContent.find(parentElement).nextAll() : $(parentElement).nextAll();

        if (previousSibilings.length > 0 || nextSibilings.length > 0) {
            cssPath.indexBasedSelector = parentElement.nodeName.toLowerCase() + ":nth-child(" + (previousSibilings.length + 1) + ") > " + cssPath.indexBasedSelector;
        }
        else {
            cssPath.indexBasedSelector = parentElement.nodeName.toLowerCase() + " > " + cssPath.indexBasedSelector;
        }
        cssPath.indexBasedSelectors.push(cssPath.indexBasedSelector);
    }
    return result;
}

function getCssAttibutesCombination(element, ignoreAttributes = []) {
    var attributes = [];
    var isCssAlreadyExitsInIgnoreAttributes = false;
    var isStyleAlreadyExitsInIgnoreAttributes = false;

    if (!element) {
        return attributes;
    }

    ignoreAttributes = [...ignoreAttributes];

    if (ignoreAttributes.indexOf("class") > -1) {
        isCssAlreadyExitsInIgnoreAttributes = true;
    } else {
        ignoreAttributes.push("class");
    }

    if (ignoreAttributes.indexOf("style") > -1) {
        isStyleAlreadyExitsInIgnoreAttributes = true;
    } else {
        ignoreAttributes.push("style");
    }

    if (ignoreAttributes.indexOf("id") === -1 && element.getAttribute("id") && element.getAttribute("id").trim().length) {
        attributes.push(`[id='${escapeSpecialCharacters(element.getAttribute("id").replace(':', '\\:').replace(".", "\\.").replace("#", "\\#"))}']`);
        ignoreAttributes.push("id");
    }

    if (ignoreAttributes.indexOf("name") === -1 && element.getAttribute("name") && element.getAttribute("name").trim().length) {
        attributes.push(`[name='${escapeSpecialCharacters(element.getAttribute("name"))}']`);
        ignoreAttributes.push("name");
    }

    [...element.attributes].forEach((attribute) => {
        if (attribute.name && attribute.value && attribute.value.trim().length > 0 && ignoreAttributes.indexOf(attribute.name) === -1)
            attributes.push(`[${attribute.name}='${escapeSpecialCharacters(attribute.value)}']`);
    });

    if (isCssAlreadyExitsInIgnoreAttributes === false && element.getAttribute("class") && element.getAttribute("class").trim().length) {
        let classes = element.getAttribute("class").replace("addon-hover", " ").replace("  ", " ").trim();
        attributes.push(`[class='${classes}']`);
    }

    if (isStyleAlreadyExitsInIgnoreAttributes === false && element.getAttribute("style") && element.getAttribute("style").trim().length) {
        attributes.push(`[style='${escapeSpecialCharacters(element.getAttribute("style"))}']`);
    }
    return getCombinations(attributes, attributeSplitter);
}

function trySiblingsCombinationsCSS(selectedElement){
    var additionalAttributes=[];    
    var result={
        path:"",
        foundUnique:false
    };
    var selectedEleAllCombinations = getCssAttibutesCombination(selectedElement, globalIgnoreAttributes);
    var prevSibling=jQuery(selectedElement.element).prev();    
    var immediatePreviousElement=getCSSElementsCombinations(prevSibling);
    var requiredParameters={
        referenceElementCombinations:immediatePreviousElement,
        selectedElementCombinations:selectedEleAllCombinations,
        selectedElement:selectedElement,
        relation:"{0} + {1}"
    };
    result=generateCSSSelectorAndResult(requiredParameters);
    if(result.foundUnique){
        return result;
    }
    var prevAllSiblings=jQuery(selectedElement.element).prevAll();
    var previousElementsCombinations=getCSSElementsCombinations(prevAllSiblings);
    requiredParameters={
        referenceElementCombinations:previousElementsCombinations,
        selectedElementCombinations:selectedEleAllCombinations,
        relation:"{0} ~ {1}",
        selectedElement:selectedElement
    };
    result=generateCSSSelectorAndResult(requiredParameters);
    if(result.foundUnique){
        return result;
    }
    return result;
}

function getCSSElementsCombinations(elements){
    var elementCombinations=[];
    for(let i=0;i<elements.length;i++){
        elementCombinations.push({
            key:elements[i],
            value:getCssAttibutesCombination(elements[i],globalIgnoreAttributes)
        });
    }
    return elementCombinations;
}
function generateCSSSelectorAndResult(requiredParameters={}){
    var {referenceElementCombinations,selectedElement,selectedElementCombinations,relation}=requiredParameters;
    var childPath="";
    var parentPath="";
    var result={
        path:"",
        foundUnique:false
    };
    var nodeName=selectedElement.nodeName.toLowerCase();
    if(typeof nodeName=='undefined'){
        nodeName=selectedElement.element!=null?selectedElement.element.nodeName.toLowerCase():selectedElement.key.element.nodeName.toLowerCase();
    }
    for(let i=0;i<referenceElementCombinations.length;i++){
        for(let j=0;j<referenceElementCombinations[i].value.length;j++){
            childPath=referenceElementCombinations[i].key.nodeName.toLowerCase()+referenceElementCombinations[i].value[j];
            if(selectedElementCombinations.length>0){
                for(let k=0;k<selectedElementCombinations.length;k++){
                    parentPath=nodeName+selectedElementCombinations[k];
                    path=[relation.replace("{0}",childPath).replace("{1}",parentPath)];
                    if(checkCssUnique(path)){
                        result.path=relation.replace("{0}",childPath).replace("{1}",parentPath);
                        result.foundUnique=true;
                        return result;
                    }
                }
            }
        }
    }
    return result;
}


function getElementsByXPath(xpath, parent) {
    let results = [];
    let query=[];
    try {
        if (!parent && iframeContent) {
            parent = iframeContent[0];            
        }
        if(iframeContent){
            query = document.evaluate(xpath,
                iframeContent[0],
                null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
            for (let i = 0, length = query.snapshotLength; i < length; ++i) {
                results.push(query.snapshotItem(i));
            }
        }
        query = document.evaluate(xpath,
            document,
            null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
        for (let i = 0, length = query.snapshotLength; i < length; ++i) {
            results.push(query.snapshotItem(i));
        }
    } catch (ex) {
        console.error(ex);
    }
    return results;
}

function checkUniqueXpath(path) {
    return getElementsByXPath("//" + path.join("/")).length == 1;
}

function checkUnique(path) {
    try {
        var elementsCount = jQuery(path.join(" > "));
        elementsCount=iframeContent ? [...elementsCount,iframeContent.find(path.join(" > "))] :elementsCount; 
        return elementsCount.length == 1;
    }
    catch (e) {
        return false;
    }
}

function checkCssUnique(path) {
    try {
        if (iframeContent){
            let result=iframeContent[0].querySelectorAll(path.join(" > ")).length;
            result+=document.querySelectorAll(path.join(" > ")).length;
            return result==1;
        }            
        else
            return document.querySelectorAll(path.join(" > ")).length == 1;
    }
    catch (e) {
        return false;
    }
}





function cssTreeExpand() {
    jQuery("[class *= 'addon-elemtree']:not(.addon-elemtree-css)").animate({
        height: "0px"
    }, "slow").css("border", "none");
    jQuery("[class ^= 'addon-expand']:not(.addon-expand-css)").css("transform", "rotate(0deg)");
    jQuery(".addon-elemtree-css").animate({
        height: "150px"
    }, "slow").css("border", "solid 1px #aaaaaa");    
}

function cssTreeCollapse() {    
    jQuery(".addon-elemtree-css").animate({
        height: "0px"
    }, "slow").css("border", "none");
}

function jQueryTreeExpand() {
    jQuery("[class *= 'addon-elemtree']:not(.addon-elemtree-jquery)").animate({
        height: "0px"
    }, "slow").css("border", "none");
    jQuery("[class ^= 'addon-expand']:not(.addon-expand-jquery)").css("transform", "rotate(0deg)");
    jQuery(".addon-elemtree-jquery").animate({
        height: "150px"
    }, "slow").css("border", "solid 1px #aaaaaa");    
}

function jQueryTreeCollapse() {    
    jQuery(".addon-elemtree-jquery").animate({
        height: "0px"
    }, "slow").css("border", "none");
}

function xpathTreeCollapse() {    
    jQuery(".addon-elemtree-xpath").animate({
        height: "0px"
    }, "slow").css("border", "none");
    jQuery(this).css("transform", "rotate(0deg)");
}

function xPathTreeExpand() {
    jQuery("[class *= 'addon-elemtree']:not(.addon-elemtree-xpath)").animate({
        height: "0px"
    }, "slow").css("border", "none");
    jQuery("[class ^= 'addon-expand']:not(.addon-expand-xpath)").css("transform", "rotate(0deg)");
    jQuery(".addon-elemtree-xpath").animate({
        height: "150px"
    }, "slow").css("border", "solid 1px #aaaaaa");
    jQuery(this).css("transform", "rotate(270deg)");    

}




function createFooter() {
    jQuery("body").append("<div id=\"graft-chrm-ext\" spellcheck=\"false\" class=\"addon-footer\" data-stop=\"false\">" +
        "<div id=\"addonMain\" class=\"addon-main\">" +
        "<a style=\"float:left !important;\" href=\"https://ggktech.com/\" target=\"_blank\"><img id=\"ggk-logo\" src=\"https://ggktech.com/wp-content/uploads/2018/07/ggktech.svg.png\"></a>" +
        "<b style=\"font-size:16px; font-weight: bold;margin-left: 60px; float:left !important;\">Element Inspector</b>" +                
        "<div id=\"downloadDropDn\" class=\"addon-dropdown-content\">" +
        "<a id=\"addon-dwnld-prop\">Prop file</a> " +
        "<a id=\"addon-dwnld-java\">Java</a>" +
        "<a id=\"addon-dwnld-csharp\">C#</a>"+
        "<a id=\"addon-dwnld-robot\">Robot Framework</a>" +
        "</div>" +        

        "<div id=\"clipBrdDropDn\" class=\"addon-dropdown-content\">" +
        "<a id=\"addon-copy-prop\">Prop file</a> " +
        "<a id=\"addon-copy-java\">Java</a>" +
        "<a id=\"addon-copy-csharp\">C#</a>"+
        "<a id=\"addon-copy-robot\">Robot Framework</a>" +
        "</div>" +
        
        "<div style=\"float:left !important\">" +
        "<input style=\"background-color:#FFFFFF;\" class=\"addon-value1\" id =\"keyname\" placeholder=\"Enter key name for locator\"></input>" +

        "<div class=\"addon-btn\" id=\"addonSelected\" title=\"Add Locator\"></div>    " +

        "<div class=\"addon-eval\" title=\"Highlight\"></div>" + "</div>" +

        "<div class=\"addon-label\"></div> " +
        "<div class=\"addon-label\"></div> " +

        "<div id=\"tableLayout\" style=\"padding-left: 10px; float:left !important;\"></div>" +       
        "<div id=\"uiOptions\">" +       

        "<div style=\"float:left !important\" id=\"jqueryHide\">" +
        "<div class=\"addon-label\"></div> " +
        "<div class=\"addon-jquery-wrapper\">"+
        "<div style=\"background-color:#FFFFFF;\" class=\"addon-value\" id =\"addonPath\"><span contenteditable=\"true\"></span></div>" +
        "<div class=\"addon-expand-jquery\"></div>" +
        "</div>"+
        "<div class=\"addon-elemtree-jquery\">" +
        "</div>" +
        "</div>" +

        "<div style=\"float:left !important\" id=\"xpathHide\">" +
        "<div class=\"addon-label\"></div>" +
        "<div class=\"addon-xpath-wrapper\">"+
        "<div style=\"background-color:#FFFFFF;\" class=\"addon-value\" id =\"addonXPath\"><span contenteditable=\"true\"></span></div>" +
        "<div class=\"addon-expand-xpath\"></div>" +        
        "</div>"+
        "<div class=\"addon-elemtree-xpath\">" +
        "</div>" +
        "</div>" +

        "<div style=\"float:left !important\" id=\"cssHide\">" +
        "<div class=\"addon-label\"></div>" +
        "<div class=\"addon-css-wrapper\">"+
        "<div style=\"background-color:#FFFFFF;\" class=\"addon-value\" id =\"addonCss\"><span contenteditable=\"true\"></span></div>" +
        "<div class=\"addon-expand-css\"></div>" +        
        "</div>"+
        "<div class=\"addon-elemtree-css\">" +
        "</div>" +
        "</div>" +

        "<div style=\"float:left !important\" id=\"xpath2Hide\">" +
        "<div class=\"addon-label\"></div>" +        
        "<div style=\"background-color:#FFFFFF;\" class=\"addon-value\" id =\"addonXPath2\"><span contenteditable=\"true\"></span></div>" +        
        "</div>" +

        "<div style=\"float:left !important\" id=\"idHide\">" +
        "<div class=\"addon-label\"></div> " +
        "<div style=\"background-color:#FFFFFF;\" class=\"addon-value\" id =\"addonId\"><span contenteditable=\"true\"></span></div>" +
        "</div>" +

        "<div style=\"float:left !important\" id=\"nameHide\">" +
        "<div class=\"addon-label\"></div> " +
        "<div style=\"background-color:#FFFFFF;\" class=\"addon-value\" id =\"addonName\"><span contenteditable=\"true\"></span></div>" +
        "</div>" +

        "<div style=\"float:left !important\" id=\"textHide\">" +
        "<div class=\"addon-label\"></div> " +
        "<div style=\"background-color:#FFFFFF;\" class=\"addon-value\" id =\"addonText\"><span contenteditable=\"true\"></span></div>" +
        "</div>" +
        "<div style=\"margin:10px;\"><label style=\"margin-right:20px; display:inline-block !important; float:left !important\"><input type=\"radio\" name=\"sortOrder\" value=\"Child-to-Parent\" checked id=\"sortOrderAscend\"/>Child-to-Parent</label><label style=\"display:inline-block !important; float:left !important\"><input type=\"radio\" value=\"Parent-to-Child\" name=\"sortOrder\" id=\"sortOrderDescend\"/>Parent-to-Child</label></div>" +        
        "<br/><div id=\"info-notify\" class=\"addon-label\" style=\"display:inline-flex !important;float:left !important\"></div>" +
        "</div>" +
        "</div>"+
        "<div id=\"sidebarAddon\" class=\"addon-sidebar\">"+
        "<div class=\"addon-close-button\" title=\"Close\"></div>" +
        "<div class=\"addon-copy-button\"   title=\"Download file\"></div>" +
        "<div class=\"addon-clipbrd-button\"   title=\"Copy to Clipboard\"></div>" +
        "<div class=\"addon-addsettings-button\" title=\"View/Hide Saved Locators\"></div>" +
        "</div>"+
        "</div>"
    );
       jQuery("#idHide").hide();
       jQuery("#textHide").hide();
       jQuery("#nameHide").hide();

    $("#downloadDropDn, #clipBrdDropDn").on("click", function () {
        $(this).removeClass("addon-show");
    });

    jQuery("#addon-copy-prop").click(
        function () {
            var samp = "";
            for (var each in objectMap) {
                samp += "\r\n" + (each + " = " + objectMap[each]) + ")";
            }
            var jQuerytemp = jQuery("<textarea>");
            jQuery("body").append(jQuerytemp);
            jQuerytemp.val(samp.trim()).select();
            document.execCommand("copy");
            jQuerytemp.remove();
        }
    );

    jQuery("#addon-copy-java").click(
        function () {
            var samp = "";
            for (var each in objectMap) {
                samp += "\r\npublic static By" + (each + " = " + objectMap[each].replace('(', '(\"')) + "\");";
            }
            var jQuerytemp = jQuery("<textarea>");
            jQuery("body").append(jQuerytemp);
            jQuerytemp.val(samp.trim()).select();
            document.execCommand("copy");
            jQuerytemp.remove();
        }
    );

    jQuery("#addon-copy-csharp").click(
        function () {
            var samp = "";
            for (var each in objectMap) {
                samp += "\r\npublic static By" + (each + " = " + objectMap[each].replace('(', '(\"')) + "\");";
            }
            var jQuerytemp = jQuery("<textarea>");
            jQuery("body").append(jQuerytemp);
            jQuerytemp.val(samp.trim()).select();
            document.execCommand("copy");
            jQuerytemp.remove();
        }
    );

    jQuery("#addon-copy-robot").click(
        function () {
            var samp = "";
            for (var each in objectMap) {
                index = objectMap[each].indexOf('(');
                split1 = objectMap[each].substr(0, index);
                split2 = objectMap[each].substr(index + 1);
                samp += "\r\n";
                if (split1 == "By.id") {
                    samp += "${" + each + "}\t" + "id=" + split2;
                }
                if (split1 == "JQuerySelector.jQuery") {
                    samp += "${" + each + "}\t" + "jquery=" + split2;
                }
                if (split1 == "By.xpath") {
                    samp += "${" + each + "}\t" + "xpath=" + split2;
                }
                if (split1 == "By.cssSelector") {
                    samp += "${" + each + "}\t" + "css=" + split2;
                }
                if (split1 == "By.tagName") {
                    samp += "${" + each + "}\t" + "tag=" + split2;
                }
                if (split1 == "By.className") {
                    samp += "${" + each + "}\t" + "class=" + split2;
                }
                if (split1 == "By.linkText") {
                    samp += "${" + each + "}\t" + "link=" + split2;
                }
                if (split1 == "By.name") {
                    samp += "${" + each + "}\t" + "identifier=" + split2;
                }
            }




            var jQuerytemp = jQuery("<textarea>");
            jQuery("body").append(jQuerytemp);
            jQuerytemp.val(samp.trim()).select();
            document.execCommand("copy");
            jQuerytemp.remove();
        }
    );

    jQuery("#addon-dwnld-prop").click(
        function () {
            var samp = "";
            for (var each in objectMap) {
                samp += "\r\n" + (each + " = " + objectMap[each]) + ")";
            }
            download("OR.properties", samp.trim());
        }
    );

    jQuery("#addon-dwnld-java").click(
        function () {
            var samp = "import org.openqa.selenium.By;\r\n\r\n"
                + "public class ObjectRepo {";
            for (var each in objectMap) {
                samp += "\r\n\tpublic static By " + (each + " = " + objectMap[each].replace('(', '(\"')) + "\");";
            }
            samp += "\r\n}";
            download("ObjectRepo.java", samp.trim());
        }
    );
    jQuery("#addon-dwnld-csharp").click(
        function () {
            var samp = "using OpenQA.Selenium;\r\n\r\n"
                + "public class ObjectRepo {";
            for (var each in objectMap) {
                samp += "\r\n\tpublic static By " + (each + " = " + objectMap[each].replace('(', '(\"')) + "\");";
            }
            samp += "\r\n}";
            download("ObjectRepo.cs", samp.trim());
        }
    );

    jQuery("#addon-dwnld-robot").click(
        function () {
            var samp = "*** Variables ***\r\n";
            for (var each in objectMap) {
                index = objectMap[each].indexOf('(');
                split1 = objectMap[each].substr(0, index);
                split2 = objectMap[each].substr(index + 1);
                samp += "\r\n";
                if (split1 == "By.id") {
                    samp += "${" + each + "}\t" + "id=" + split2;
                }
                if (split1 == "JQuerySelector.jQuery") {
                    samp += "${" + each + "}\t" + "jquery=" + split2;
                }
                if (split1 == "By.xpath") {
                    samp += "${" + each + "}\t" + "xpath=" + split2;
                }
                if (split1 == "By.cssSelector") {
                    samp += "${" + each + "}\t" + "css=" + split2;
                }
                if (split1 == "By.tagName") {
                    samp += "${" + each + "}\t" + "tag=" + split2;
                }
                if (split1 == "By.className") {
                    samp += "${" + each + "}\t" + "class=" + split2;
                }
                if (split1 == "By.linkText") {
                    samp += "${" + each + "}\t" + "link=" + split2;
                }
                if (split1 == "By.name") {
                    samp += "${" + each + "}\t" + "identifier=" + split2;
                }

            }
            download("ObjectRepo.robot", samp.trim());
        }
    );
    

    jQuery(".addon-elemtree-css").animate({
        height: "0px"
    });
    jQuery(".addon-expand-css").click(
        function () {
            if (jQuery(".addon-elemtree-css").height() != "0") {
                cssTreeCollapse();
                jQuery(this).css("transform", "rotate(0deg)");
            } else {
                cssTreeExpand();
                jQuery(this).css("transform", "rotate(270deg)");
            }
        }
    );

    jQuery(".addon-elemtree-jquery").animate({
        height: "0px"
    });
    jQuery(".addon-expand-jquery").click(
        function () {
            if (jQuery(".addon-elemtree-jquery").height() != "0") {
                jQueryTreeCollapse();
                jQuery(this).css("transform", "rotate(0deg)");
            } else {
                jQueryTreeExpand();
                jQuery(this).css("transform", "rotate(270deg)");
            }
        }
    );

    jQuery(".addon-elemtree-xpath").animate({
        height: "0px"
    });
    jQuery(".addon-expand-xpath").click(
        function () {
            if (jQuery(".addon-elemtree-xpath").height() != "0") {
                xpathTreeCollapse();
                jQuery(this).css("transform", "rotate(0deg)");
            }
            else {
                xPathTreeExpand();
                jQuery(this).css("transform", "rotate(270deg)");
            }

        }
    );

    injectOverLay();
    initiOverLay();
    jQuery(".addon-footer").mouseover(function () {
        jQuery(".addon-hover").removeClass("addon-hover");
    });
    jQuery("#addonSelected").bindFirst("click", addingSelectedOption);
    jQuery(".addon-footer").draggable({
        containment: "window"
      });
    jQuery(".addon-footer, #overlay").contextmenu(function () { return false; });
    jQuery("div.addon-eval").click(
        function () {
            try {
                if (jQuery("input[name=\'locoptns\']:checked").length == 0) {
                    alert("Select a locator to evaluate");
                    return;
                }
                var matchingEleCount = 0;
                var hiddenEleCount = 0;
                var allElems = [];
                var toAdd = jQuery("input[name=\"locoptns\"]:checked").attr("toAdd");
                var selectorToEval = jQuery("input[name=\"locoptns\"]:checked").attr("toEval");
                var t = null;
                //elemnets in direct DOM
                if (toAdd.startsWith("By.xpath")) {
                    t = getElementsByXPath(selectorToEval, document);
                    t = $(t).not(".addon-footer *");
                    t = t.not(".addon-footer");
                    t = t.not("#overlay");
                    if (t && t.length > 0) {
                        allElems = allElems.concat(Array.from(t));
                        hiddenEleCount = hiddenElementsCount(allElems);
                    }
                }
                else if (toAdd.startsWith("By.css")) {
                    t = document.querySelectorAll(selectorToEval);
                    t = $(t).not(".addon-footer *");
                    t = t.not(".addon-footer");
                    t = t.not("#overlay");
                    if (t && t.length > 0) {
                        allElems = allElems.concat(Array.from(t));
                        hiddenEleCount = hiddenElementsCount(allElems);
                    }
                }
                else {
                    t = $(selectorToEval).not(".addon-footer *");
                    t = t.not(".addon-footer");
                    t = t.not("#overlay");
                    if (t && t.length > 0) {
                        allElems = allElems.concat(t.toArray());
                        hiddenEleCount = hiddenElementsCount(allElems);
                    }
                }

                if (toAdd.startsWith("By.xpath") || toAdd.startsWith("By.css")) {
                    jQuery.each(allElems, function (index, item) {
                        var _this = $(item);
                        _this.not(".addon-footer, .addon-footer *").addClass("addon-highlight");
                        setTimeout(function (e) {
                            e.removeClass("addon-highlight");
                        }, 2000, _this);
                    })
                } else {
                    $(selectorToEval).not(".addon-footer, .addon-footer *").addClass("addon-highlight");
                    setTimeout(function () {
                        $(selectorToEval).removeClass("addon-highlight");
                    }, 2000);
                }

                //elements in iframedocument.getElementsByTa
                var iframes = document.getElementsByTagName("iframe");
                var e = null;
                var iframeEle = null;
                try {
                    for (var i = 0; i < iframes.length; i++) {

                        if (toAdd.startsWith("By.xpath"))
                            iframeEle = getElementsByXPath(selectorToEval, iframes[i].contentWindow.document);
                        else if (toAdd.startsWith("By.css"))
                            iframeEle = iframes[i].contentWindow.document.querySelectorAll(selectorToEval);
                        else
                            iframeEle = jQuery(iframes[i]).contents().find(selectorToEval);

                        e = jQuery(iframeEle);
                        if (e && e.length > 0) {
                            e.addClass("addon-highlight");
                            setTimeout(function (e) {
                                e.removeClass("addon-highlight");
                            }, 2000, e);
                            hiddenEleCount += hiddenElementsCount(e.toArray(), iframes[i].contentWindow);
                            allElems = allElems.concat(e.toArray());
                        }
                    }
                } catch (err) {
                    console.error(err);
                }

                matchingEleCount = allElems.length;
                if (matchingEleCount == 0) {
                    alert("No locator has been found");
                    return;
                }

                blinkHighlighted();
                let isAnyElementInViewPort = false;
                for (let i = 0; i < matchingEleCount; i++) {
                    var rect = allElems[0].getBoundingClientRect();

                    if (rect.top >= 0 &&
                        rect.left >= 0 &&
                        rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
                        rect.right <= (window.innerWidth || document.documentElement.clientWidth)
                    ) {
                        isAnyElementInViewPort = true;
                        break;
                    }
                }
                if (!isAnyElementInViewPort) {
                    $([document.documentElement, document.body]).animate({
                        scrollTop: ($(allElems[0]).offset().top - 100)
                    }, 200);
                }
                //scrollToElement(allElems);

                //hiddenEleCount = hiddenElementsCount(allElems);
                var displayMessage = "<b>Matching locators count: </b>" + matchingEleCount;
                if (hiddenEleCount > 0) {
                    displayMessage += "<br/> <b>Hidden locators count: </b>" + hiddenEleCount;
                }
                displayAdditionalInfo(displayMessage);
            } catch (err) {
                alert(err.message.replace(':not(.addon-footer, .addon-footer *)', ''));
            }
        }

    );
    rootElement=jQuery(".addon-main");
    lastHeight=jQuery("addon-main").css('height');
    checkForChanges();
};

function initiOverLay() {

    new MutationObserver(function (mutations) {
        mutations.forEach(function (mutationRecord) {
            if (!((jQuery(".addon-footer").length === 0) || (jQuery(".addon-footer").data("stop")))) {
                jQuery("#overlay").hide();
            }
        });
    }).observe(document.getElementById('overlay'), {
        attributes: true,
        attributeFilter: ['style']
    });



    jQuery(document).off("mousemove").on("mousemove",
        function (event) {
            if (!isExtesionClose)
                mouseMoveHandler(event);
        }
    );

    jQuery(document).off("contextmenu").on("contextmenu",
        function (event) {
            if (!isExtesionClose)
                mouseClickHandler(event);
        }
    );

    jQuery("iframe").each(function () {
        $(this).contents().off("mousemove").on("mousemove", function (event) {
            if (!isExtesionClose)
                mouseMoveHandler(event);
        });
    });

    jQuery("iframe").each(function () {
        $(this).contents().off("contextmenu").on("contextmenu", function (event) {
            if (!isExtesionClose)
                mouseClickHandler(event);
        });
    });

    jQuery("#overlay").mouseout(
        function (event) {
            jQuery(".addon-hover").removeClass("addon-hover");
            removeClassFromIframe();
        });
}


function addingSelectedOption() {
    if (validateKeyName() == false) {
        return;
    }
    objectMap[jQuery("#keyname").val()] = jQuery("input[name=\'locoptns\']:checked").attr("toadd");
    addBackupValues();
    syncToChromeStorage();
    jQuery("#keyname").val("");
    isEditing = false;
}



function removeClassFromIframe() {
    if (iframeContent) {
        iframeContent.find(".addon-hover").removeClass("addon-hover");
    }
}

function mouseMoveHandler(event) {
    var parents = $(event.target).parents(":not(body,html)");
    var hasClass = false;
    if ($(event.target).hasClass("addon-footer"))
        hasClass = true;

    jQuery.each(parents, function (index, item) {
        if ($(item).hasClass("addon-footer"))
            hasClass = true;
    });

    if (!hasClass) {
        event.preventDefault();
        event.stopPropagation();
        hideOverLay();
        jQuery(".addon-hover").removeClass("addon-hover");
        if (jQuery(".addon-footer").length === 0) return;
        if (jQuery(".addon-footer").data("stop")) return;
        var element = getElement(event);
        jQuery(element).addClass("addon-hover");
        showOverLay();
    }
}

function getElement(event) {
    var ele = event.target;
    removeClassFromIframe();

    if (event.target.ownerDocument != document) {
        var iframeDoc = event.target.ownerDocument;
        if (!iframeDoc.getElementById("add-on-css")) {
            var css = ' .addon-hover { outline: 3px dashed rgb(41, 128, 185) !important; background-color: rgb(148, 212, 252) !important; }  .addon-highlight { outline: 3px dashed #FF9900 !important; background-color: #FFFFCC !important; } ',
                head = iframeDoc.head || iframeDoc.getElementsByTagName('head')[0],
                style = iframeDoc.createElement('style');

            head.appendChild(style);
            style.type = 'text/css';
            style.setAttribute("id", "add-on-css");
            style.appendChild(document.createTextNode(css));
        }

        $(iframeDoc).find(".addon-hover").removeClass("addon-hover");
        iframeContent = $(iframeDoc);
        return ele;
    } else {
        return ele;
    }
}

function getsortOrder(inputName) {
    return jQuery("input[name=" + inputName + "]:checked").val();
}

function initialiseDefaultValues() {
    sortOrder=childToParent;
    jQuery("#sortOrderAscend").prop("checked", true);
}


function mouseClickHandler(event) {
    var parents = $(event.target).parents(":not(body,html)");
    var hasClass = false;
    if ($(event.target).hasClass("addon-footer"))
        hasClass = true;

    jQuery.each(parents, function (index, item) {
        if ($(item).hasClass("addon-footer"))
            hasClass = true;
    });


    if (!hasClass) {
        initialiseDefaultValues();
        event.stopPropagation();
        event.preventDefault();
        hideOverLay();
        if (jQuery(".addon-footer").length === 0) return;
        if (jQuery(".addon-footer").data("stop")) return;
        jQuery("[class^='addon-expand']").show();
        jQuery("[class *= 'addon-elemtree']")
            .height("0px")
            .css("border", "none");
        jQuery("[class ^= 'addon-expand']")
            .css("transform", "rotate(0deg)");        

        iframeContent = null;
        iframeInfo = "";
        populateLoc(getElement(event));
        showOverLay();
    }
}

function showXpathElementTree(element) {
    var tree = "";
    var t = element;
    var tabNumber = 1;
    var tabButtons = [];
    while (true) {
        var allAttribs = t.attributes;
        var samp = "";
        var tempEle = iframeContent ? iframeContent.find(t) : jQuery(t);
        for (var eachAttrib in allAttribs) {
            if (allAttribs[eachAttrib].name && allAttribs[eachAttrib].value) {
                if (allAttribs[eachAttrib].name == 'class') {
                    allAttribs[eachAttrib].value = allAttribs[eachAttrib].value.replace("addon-hover", " ").replace("  ", " ").trim();
                    if (allAttribs[eachAttrib].value) {
                        eachClss = allAttribs[eachAttrib].value.split(" ");
                        for (eachCls in eachClss) {
                            samp += "<button title=\"class = '" + eachClss[eachCls] + "'\" addon-key=\"class\" addon-value=\"" + encodeDoubleQoutes(eachClss[eachCls]) + "\" class=\"addon-attrib-disabled\">" + "class" +
                                "='" + eachClss[eachCls] + "'</button>";
                        }
                    }
                } else {
                    samp += "<button title=\"" + allAttribs[eachAttrib].name + "='" + encodeDoubleQoutes(escapeSpecialCharacters(allAttribs[eachAttrib].value)) + "'\" addon-key=\"" +
                        allAttribs[eachAttrib].name + "\" addon-value=\"" + encodeDoubleQoutes(allAttribs[eachAttrib].value) +
                        "\" class=\"addon-attrib-disabled\">" +
                        allAttribs[eachAttrib].name + "='" +
                        (allAttribs[eachAttrib].value.length < 20 ? allAttribs[eachAttrib].value : allAttribs[eachAttrib].value.substr(0, 15) + "...") + "'</button>";
                }
            }
        }
        let eleText = getFirstTextNodeValue(tempEle);
        let trimmedEleText = eleText.replace(/(\r\n|\n|\r)/gm, "").trim();
        if (trimmedEleText.length > 0) {
            let encodedText = encodeHtmlSpecialCharacters(trimmedEleText)
            samp += "<button title=\"text = '" + encodeDoubleQoutes(escapeSpecialCharacters(trimmedEleText)) + "'\" addon-key=\"text\" addon-value=\"" + encodeDoubleQoutes(eleText) + "\" class=\"addon-attrib-disabled\">" +
                "text" + "='" + (encodedText.length < 20 ? encodedText : encodedText.substr(0, 15) + "...")
                + "'</button>";
        }

        tree += "<div class=\"addon-tabs\" tabnumber=\"" + tabNumber + "\"><b>" + tempEle[0].nodeName.toLowerCase() + "</b> : " + samp + "</div>";
        tabButtons.push("<button class=\"navbuttons\" buttonnumber =\"" + tabNumber + "\">" + tempEle[0].nodeName.toLowerCase() + "</button>");
        if (tempEle[0].nodeName == "HTML") break;
        t = t.parentNode;
        tabNumber += 1;
    }
    jQuery(".addon-elemtree-xpath").empty();
    jQuery(".addon-elemtree-xpath").append(tabButtons.join(">") + "<hr>" + tree);
    jQuery(".addon-footer .addon-elemtree-xpath div.addon-tabs").hide();
    jQuery(".addon-footer .addon-elemtree-xpath button.addon-attrib-disabled, .addon-footer .addon-elemtree-xpath button.addon-attrib-enabled").click(
        function () {
            hideAdditionalInfo();
            if (jQuery(this).attr("class") == "addon-attrib-disabled") {
                jQuery(this).removeClass("addon-attrib-disabled");
                jQuery(this).addClass("addon-attrib-enabled");
            } else {
                jQuery(this).removeClass("addon-attrib-enabled");
                jQuery(this).addClass("addon-attrib-disabled");
            }
            if (jQuery(".addon-elemtree-xpath").height() != "0") {
                try {
                    var activeEle = jQuery(".addon-footer .addon-elemtree-xpath button.navbuttons.active");
                    var selector = "";
                    var buttonNumber = activeEle.attr("buttonnumber");
                    selector = activeEle.text();
                    selector += getXpathNavEleProperties(buttonNumber);
                    if (sortOrder == childToParent) {
                        activeEle.nextAll("button.navbuttons").each(function () {
                            selector = jQuery(this).text() + getXpathNavEleProperties(jQuery(this).attr("buttonnumber")) + "/" + selector;
                        });
                    }
                    else if (sortOrder == parentToChild) {
                        activeEle.prevAll("button.navbuttons").each(function () {
                            selector = selector + "/" + jQuery(this).text() + getXpathNavEleProperties(jQuery(this).attr("buttonnumber"));
                        });
                    }
                    selector = "//" + selector;
                    let encodedSelector = encodeDoubleQoutes(selector);
                    jQuery("#addonXPath").html("<input type=\"radio\" name=\"locoptns\" toadd=\"" + "By.xpath(" + encodedSelector + "\"  toEval=\"" + encodedSelector + "\"></input>" + "<b>Xpath : </b>" +
                        "<span contenteditable=\"true\">" + encodeHtmlSpecialCharacters(selector) + "</span>");
                    initSpan();

                } catch (err) { }
            }
        }
    );
    jQuery(".addon-footer .addon-elemtree-xpath button.navbuttons").click(
        function () {
            hideAdditionalInfo();

            jQuery(".addon-footer .addon-elemtree-xpath button.navbuttons.active").removeClass("active");
            jQuery(this).addClass("active");
            jQuery(".addon-footer .addon-elemtree-xpath div.addon-tabs").hide();
            jQuery(".addon-footer .addon-elemtree-xpath div.addon-tabs[tabnumber='" + jQuery(this).attr("buttonnumber") + "']").show();

            var selector = "";
            selector = getXpathNavigationElement(jQuery(this));
            if (sortOrder == childToParent) {
                jQuery(this).nextAll("button.navbuttons").each(function () {
                    selector = getXpathNavigationElement(jQuery(this)) + "/" + selector;
                });
                selector = "//" + selector;
            }
            else if (sortOrder == parentToChild) {
                let prevAllXPath = selector;
                jQuery(this).prevAll("button.navbuttons").each(function () {
                    prevAllXPath = prevAllXPath + "/" + getXpathNavigationElement(jQuery(this));
                });
                selector = "//" + prevAllXPath;
            }
            let encodedSelector = encodeDoubleQoutes(selector);
            jQuery("#addonXPath").html("<input type=\"radio\" name=\"locoptns\" toadd=\"" + "By.xpath(" + encodedSelector + "\"  toEval=\"" + encodedSelector + "\"></input>" + "<b>Xpath : </b>" +
                "<span contenteditable=\"true\">" + encodeHtmlSpecialCharacters(selector) + "</span>");
            initSpan();
        }
    );
    jQuery(".addon-footer .addon-elemtree-xpath button.navbuttons[buttonnumber='1']").click();    
}

function getXpathNavEleProperties(navBtnNumber) {
    var tabs = jQuery(".addon-footer .addon-elemtree-xpath div.addon-tabs[tabnumber='" + navBtnNumber + "']");
    var activeProperties = tabs.find("button.addon-attrib-enabled");
    var selector = "";

    var idEle = activeProperties.filter("button[addon-key='id']");
    if (idEle.length) {
        selector = "[@id=\'" + idEle.attr("addon-value") + "']";
    }

    var nameEle = activeProperties.filter("button[addon-key='name']");
    if (nameEle.length) {
        if (nameEle.attr("addon-value").indexOf("'") > -1)
            selector += "[@name=\"" + nameEle.attr("addon-value") + "\"]";
        else
            selector += "[@name='" + nameEle.attr("addon-value") + "']";
    }

    var classEles = activeProperties.filter("button[addon-key='class']");
    if (classEles.length && tabs.find("button[addon-key='class']").length == 1) {
        if (jQuery(classEles[0]).attr("addon-value").indexOf("'") > -1)
            selector += "[@class=\"" + jQuery(classEles[0]).attr("addon-value") + "\"]";
        else
            selector += "[@class='" + jQuery(classEles[0]).attr("addon-value") + "']";
    }
    else {
        classEles.each(function () {
            if (jQuery(this).attr("addon-value").indexOf("'") > -1)
                selector += "[contains(@class,\"" + jQuery(this).attr("addon-value") + "\")]";
            else
                selector += "[contains(@class,'" + jQuery(this).attr("addon-value") + "')]";
        });
    }

    var textEle = activeProperties.filter("button[addon-key='text']");
    if (textEle.length) {
        var text = textEle.attr("addon-value");
        if (text.replace(/(\r\n|\n|\r)/gm, "").trim() === text) {
            if (textEle.attr("addon-value").indexOf("'") > -1)
                selector += "[text()=\"" + textEle.attr("addon-value") + "\"]";
            else
                selector += "[text()='" + textEle.attr("addon-value") + "']";
        } else {
            if (textEle.attr("addon-value").indexOf("'") > -1)
                selector += "[contains(text(),\"" + textEle.attr("addon-value").replace(/(\r\n|\n|\r)/gm, "").trim() + "\")]";
            else
                selector += "[contains(text(),'" + textEle.attr("addon-value").replace(/(\r\n|\n|\r)/gm, "").trim() + "')]";
        }
    }

    var attrEle = activeProperties.not("button[addon-key='id'],button[addon-key='name'],button[addon-key='class'],button[addon-key='text']");
    attrEle.each(function () {
        if (jQuery(this).attr("addon-value").indexOf("'") > -1)
            selector += "[@" + jQuery(this).attr("addon-key") + "=\"" + jQuery(this).attr("addon-value") + "\"]";
        else
            selector += "[@" + jQuery(this).attr("addon-key") + "='" + jQuery(this).attr("addon-value") + "']";
    });

    return selector;
}

function getXpathNavigationElement(ele) {
    var navBtnNumber = ele.attr("buttonNumber");
    var tabs = jQuery(".addon-footer .addon-elemtree-xpath div.addon-tabs[tabnumber='" + navBtnNumber + "']");
    var node = jQuery(".addon-footer .addon-elemtree-xpath button.navbuttons[buttonnumber='" + navBtnNumber + "']").text();

    // tabs.find("button[addon-key='id']").removeClass('addon-attrib-disabled').addClass('addon-attrib-enabled');
    // tabs.find("button[addon-key='name']").removeClass('addon-attrib-disabled').addClass('addon-attrib-enabled'); 
    node += getXpathNavEleProperties(navBtnNumber);
    return node;
}




function showJqueryElementTree(element) {
    var tree = "";
    var t = element;
    var tabNumber = 1;
    var tabButtons = [];
    while (true) {
        var allAttribs = t.attributes;
        var samp = "";
        var tempEle = iframeContent ? iframeContent.find(t) : jQuery(t);
        for (var eachAttrib in allAttribs) {
            if (allAttribs[eachAttrib].name && allAttribs[eachAttrib].value) {
                if (allAttribs[eachAttrib].name == 'class') {
                    allAttribs[eachAttrib].value = allAttribs[eachAttrib].value.replace("addon-hover", " ").replace("  ", " ").trim();
                    if (allAttribs[eachAttrib].value) {
                        eachClss = allAttribs[eachAttrib].value.split(" ");
                        for (eachCls in eachClss) {
                            samp += "<button title=\"class = '" + eachClss[eachCls] + "'\" addon-key=\"class\" addon-value=\"" + encodeDoubleQoutes(eachClss[eachCls]) + "\" class=\"addon-attrib-disabled\">" + "class" + "='" + eachClss[eachCls] + "'</button>";
                        }
                    }
                } else {
                    samp += "<button title=\"" + allAttribs[eachAttrib].name + "='" + encodeDoubleQoutes(escapeSpecialCharacters(allAttribs[eachAttrib].value)) + "'\" addon-key=\"" + allAttribs[eachAttrib].name + "\" addon-value=\"" + encodeDoubleQoutes(allAttribs[eachAttrib].value) + "\" class=\"addon-attrib-disabled\">" + allAttribs[eachAttrib].name + "='" +
                        (allAttribs[eachAttrib].value.length < 20 ? allAttribs[eachAttrib].value : allAttribs[eachAttrib].value.substr(0, 15) + "...") + "'</button>";
                }
            }
        }

        let eleText = getFirstTextNodeValue(tempEle);
        let trimmedEleText = eleText.replace(/(\r\n|\n|\r)/gm, "").trim();
        if (trimmedEleText.length > 0) {
            let decodedText = decodeHtmlSpecialCharacters(trimmedEleText);
            let encodedText = encodeHtmlSpecialCharacters(trimmedEleText)

            samp += "<button title=\"text = '" + encodeDoubleQoutes(escapeSpecialCharacters(tempEle.text())) + "'\" addon-key=\"text\" addon-value=\"" + encodeDoubleQoutes(decodedText) + "\" class=\"addon-attrib-disabled\">" + "text" + "='" +
                (encodedText.length < 20 ? encodedText : encodedText.substr(0, 15) + "...") + "'</button>";
        }

        tree += "<div class=\"addon-tabs\" tabnumber=\"" + tabNumber + "\"><b>" + tempEle[0].nodeName.toLowerCase() + "</b> : " + samp + "</div>";
        tabButtons.push("<button class=\"navbuttons\" buttonnumber =\"" + tabNumber + "\">" + tempEle[0].nodeName.toLowerCase() + "</button>");
        if (tempEle[0].nodeName == "HTML") break;
        t = t.parentNode;
        tabNumber += 1;
    }
    jQuery(".addon-elemtree-jquery").empty();
    jQuery(".addon-elemtree-jquery").append(tabButtons.join(">") + "<hr>" + tree);
    jQuery(".addon-footer .addon-elemtree-jquery div.addon-tabs").hide();
    jQuery(".addon-footer .addon-elemtree-jquery button.addon-attrib-disabled, .addon-footer .addon-elemtree-jquery button.addon-attrib-enabled").click(
        function () {
            hideAdditionalInfo();
            if (jQuery(this).attr("class") == "addon-attrib-disabled") {
                jQuery(this).removeClass("addon-attrib-disabled");
                jQuery(this).addClass("addon-attrib-enabled");
            } else {
                jQuery(this).removeClass("addon-attrib-enabled");
                jQuery(this).addClass("addon-attrib-disabled");
            }
            if (jQuery(".addon-elemtree-jquery").height() != "0") {
                var activeEle = jQuery(".addon-footer .addon-elemtree-jquery button.navbuttons.active");
                var selector = "";
                var buttonNumber = activeEle.attr("buttonnumber");
                selector = activeEle.text();
                selector += getJqueryNavEleProperties(buttonNumber);

                if (sortOrder == childToParent) {
                    activeEle.nextAll("button.navbuttons").each(function () {
                        selector = jQuery(this).text() + getJqueryNavEleProperties(jQuery(this).attr("buttonnumber")) + " > " + selector;
                    });
                }
                else if (sortOrder == parentToChild) {
                    activeEle.prevAll("button.navbuttons").each(function () {
                        selector = selector + " > " + jQuery(this).text() + getJqueryNavEleProperties(jQuery(this).attr("buttonnumber"));
                    });
                }
                let encodedSelector = encodeDoubleQoutes(selector);
                jQuery("#addonPath").html("<input type=\"radio\" name=\"locoptns\" toadd=\"" + "JQuerySelector.jQuery(" + encodedSelector + "\"  toEval=\"" + encodedSelector + "\"></input>" + "<b>Jquery : </b>" +
                    "<span contenteditable=\"true\">" + encodeHtmlSpecialCharacters(selector) + "</span>");
                initSpan();
            }
        }
    );
    jQuery(".addon-footer .addon-elemtree-jquery button.navbuttons").click(
        function () {
            hideAdditionalInfo();
            jQuery(".addon-footer .addon-elemtree-jquery button.navbuttons.active").removeClass("active");
            jQuery(this).addClass("active");
            jQuery(".addon-footer .addon-elemtree-jquery div.addon-tabs").hide();
            jQuery(".addon-footer .addon-elemtree-jquery div.addon-tabs[tabnumber='" + jQuery(this).attr("buttonnumber") + "']").show();


            var selector = "";
            selector = getJqueryNavigationElement(jQuery(this));
            if (sortOrder == childToParent) {
                jQuery(this).nextAll("button.navbuttons").each(function () {
                    selector = getJqueryNavigationElement(jQuery(this)) + " > " + selector;
                });
            }
            else if (sortOrder == parentToChild) {
                jQuery(this).prevAll("button.navbuttons").each(function () {
                    selector = selector + " > " + getJqueryNavigationElement(jQuery(this));
                });
            }
            let encodedSelector = encodeDoubleQoutes(selector);
            jQuery("#addonPath").html("<input type=\"radio\" name=\"locoptns\" toadd=\"" + "JQuerySelector.jQuery(" + encodedSelector + "\"  toEval=\"" + encodedSelector + "\"></input>" + "<b>Jquery : </b>" +
                "<span contenteditable=\"true\">" + encodeHtmlSpecialCharacters(selector) + "</span>");
            initSpan();
        }
    );
    jQuery(".addon-footer .addon-elemtree-jquery button.navbuttons[buttonnumber='1']").click();
}

function getJqueryNavEleProperties(navBtnNumber) {
    var tabs = jQuery(".addon-footer .addon-elemtree-jquery div.addon-tabs[tabnumber='" + navBtnNumber + "']");
    var activeProperties = tabs.find("button.addon-attrib-enabled");
    var selector = "";

    var idEle = activeProperties.filter("button[addon-key='id']");
    if (idEle.length) {
        selector = "#" + jQuery.escapeSelector(idEle.attr("addon-value"));
    }

    var nameEle = activeProperties.filter("button[addon-key='name']");
    if (nameEle.length) {
        selector += "[name='" + escapeSpecialCharacters(nameEle.attr("addon-value")) + "']";
    }

    var classEles = activeProperties.filter("button[addon-key='class']");
    classEles.each(function () {
        selector += "." + jQuery.escapeSelector(jQuery(this).attr("addon-value"));
    });

    var textEle = activeProperties.filter("button[addon-key='text']");
    if (textEle.length) {
        selector += ":contains(\'" + escapeSpecialCharacters(textEle.attr("addon-value")) + "')";
    }

    var attrEle = activeProperties.not("button[addon-key='id'],button[addon-key='name'],button[addon-key='class'],button[addon-key='text']");
    attrEle.each(function () {
        selector += "[" + jQuery.escapeSelector(jQuery(this).attr("addon-key")) + "='" + escapeSpecialCharacters(jQuery(this).attr("addon-value")) + "']";
    });

    return selector;
}

function getJqueryNavigationElement(ele) {
    var navBtnNumber = ele.attr("buttonNumber");
    var tabs = jQuery(".addon-footer .addon-elemtree-jquery div.addon-tabs[tabnumber='" + navBtnNumber + "']");
    var node = jQuery(".addon-footer .addon-elemtree-jquery button.navbuttons[buttonnumber='" + navBtnNumber + "']").text();

    // tabs.find("button[addon-key='id']").removeClass('addon-attrib-disabled').addClass('addon-attrib-enabled');
    // tabs.find("button[addon-key='name']").removeClass('addon-attrib-disabled').addClass('addon-attrib-enabled');
    node += getJqueryNavEleProperties(navBtnNumber);
    return node;    
}




function showElementTree(element) {
    var tree = "";
    var t = element;
    var tabNumber = 1;
    var tabButtons = [];
    while (true) {
        var allAttribs = t.attributes;
        var samp = "";
        for (var eachAttrib in allAttribs) {
            if (allAttribs[eachAttrib].name && allAttribs[eachAttrib].value) {

                if (allAttribs[eachAttrib].name == 'class') {
                    allAttribs[eachAttrib].value = allAttribs[eachAttrib].value.replace("addon-hover", " ").replace("  ", " ").trim();
                    if (allAttribs[eachAttrib].value) {
                        eachClss = allAttribs[eachAttrib].value.split(" ");
                        for (eachCls in eachClss) {
                            samp += "<button title=\"" + "class ='" + eachClss[eachCls] + "'\" addon-key=\"class\" addon-value=\"" + encodeDoubleQoutes(eachClss[eachCls]) + "\" class=\"addon-attrib-disabled\">" + "class" + "='" + eachClss[eachCls] + "'</button>";
                        }
                    }
                } else {
                    samp += "<button title=\"" + allAttribs[eachAttrib].name + "='" + encodeDoubleQoutes(escapeSpecialCharacters(allAttribs[eachAttrib].value)) + "'\" addon-key=\"" + allAttribs[eachAttrib].name +
                        "\" addon-value=\"" + encodeDoubleQoutes(allAttribs[eachAttrib].value) + "\" class=\"addon-attrib-disabled\">"
                        + allAttribs[eachAttrib].name + "='" + (allAttribs[eachAttrib].value.length < 15 ? allAttribs[eachAttrib].value : allAttribs[eachAttrib].value.substr(0, 15) + "...") + "'</button>";
                }
            }
        }

        tree += "<div class=\"addon-tabs\" tabnumber=\"" + tabNumber + "\"><b>" + t.nodeName.toLowerCase() + "</b> : " + samp + "</div>";
        tabButtons.push("<button class=\"navbuttons\" buttonnumber =\"" + tabNumber + "\">" + t.nodeName.toLowerCase() + "</button>");
        if (t.nodeName == "HTML") break;
        t = t.parentNode;
        tabNumber += 1;
    }

    jQuery(".addon-elemtree-css").empty();
    jQuery(".addon-elemtree-css").append(tabButtons.join(">") + "<hr>" + tree);
    jQuery(".addon-footer div.addon-tabs").hide();
    jQuery(".addon-footer .addon-elemtree-css button.addon-attrib-disabled, .addon-footer .addon-elemtree-css button.addon-attrib-enabled").click(
        function (event) {
            hideAdditionalInfo();
            if (jQuery(this).attr("class") == "addon-attrib-disabled") {
                jQuery(this).removeClass("addon-attrib-disabled");
                jQuery(this).addClass("addon-attrib-enabled");
            } else {
                jQuery(this).removeClass("addon-attrib-enabled");
                jQuery(this).addClass("addon-attrib-disabled");
            }
            if (jQuery(".addon-elemtree-css").height() != "0") {
                var activeEle = jQuery(".addon-footer .addon-elemtree-css button.navbuttons.active");
                var selector = "";
                var buttonNumber = activeEle.attr("buttonnumber");
                selector = activeEle.text();
                selector += getCssNavEleProperties(buttonNumber);

                if (sortOrder == childToParent) {
                    activeEle.nextAll("button.navbuttons").each(function () {
                        selector = jQuery(this).text() + getCssNavEleProperties(jQuery(this).attr("buttonnumber")) + " > " + selector;
                    });
                }
                else if (sortOrder == parentToChild) {
                    activeEle.prevAll("button.navbuttons").each(function () {
                        selector = selector + " > " + jQuery(this).text() + getCssNavEleProperties(jQuery(this).attr("buttonnumber"));
                    });
                }
                let encodedSelector = encodeDoubleQoutes(selector);
                jQuery("#addonCss").html("<input type=\"radio\" name=\"locoptns\" toadd=\"" + "By.cssSelector(" + encodedSelector + "\"  toEval=\"" + encodedSelector + "\"></input>" + "<b>Css Selector : </b>" +
                    "<span contenteditable=\"true\">" + encodeHtmlSpecialCharacters(selector) + "</span>");
                initSpan();
            }
        }
    );
    jQuery(".addon-footer .addon-elemtree-css button.navbuttons").click(
        function () {
            hideAdditionalInfo();
            jQuery(".addon-footer .addon-elemtree-css button.navbuttons.active").removeClass("active");
            jQuery(this).addClass("active");
            jQuery(".addon-footer .addon-elemtree-css div.addon-tabs").hide();
            jQuery(".addon-footer .addon-elemtree-css div.addon-tabs[tabnumber='" + jQuery(this).attr("buttonnumber") + "']").show();

            var selector = "";
            selector = getCssNavigationElement(jQuery(this));
            if (sortOrder == childToParent) {
                jQuery(this).nextAll("button.navbuttons").each(function () {
                    selector = getCssNavigationElement(jQuery(this)) + " > " + selector;
                });
            }
            else if (sortOrder == parentToChild) {
                let prevCss = selector;
                jQuery(this).prevAll("button.navbuttons").each(function () {
                    prevCss = prevCss + " > " + getCssNavigationElement(jQuery(this));
                });
                selector = prevCss;
            }
            let encodedSelector = encodeDoubleQoutes(selector);
            jQuery("#addonCss").html("<input type=\"radio\" name=\"locoptns\" toadd=\"" + "By.cssSelector(" + encodedSelector + "\"  toEval=\"" + encodedSelector + "\"></input>" + "<b>Css Selector : </b>" +
                "<span contenteditable=\"true\">" + encodeHtmlSpecialCharacters(selector) + "</span>");
            initSpan();
        }
    );
    jQuery(".addon-footer .addon-elemtree-css button.navbuttons[buttonnumber='1']").click();
}

function getCssNavEleProperties(navBtnNumber) {
    var tabs = jQuery(".addon-footer .addon-elemtree-css div.addon-tabs[tabnumber='" + navBtnNumber + "']");
    var activeProperties = tabs.find("button.addon-attrib-enabled");
    var selector = "";

    var idEle = activeProperties.filter("button[addon-key='id']");
    if (idEle.length) {
        selector = "#" + jQuery.escapeSelector(idEle.attr("addon-value"));
    }

    var nameEle = activeProperties.filter("button[addon-key='name']");
    if (nameEle.length) {
        selector += "[name='" + escapeSpecialCharacters(nameEle.attr("addon-value")) + "']";
    }

    var classEles = activeProperties.filter("button[addon-key='class']");
    classEles.each(function () {
        selector += "." + jQuery.escapeSelector(jQuery(this).attr("addon-value"));
    });

    var attrEle = activeProperties.not("button[addon-key='id'],button[addon-key='name'],button[addon-key='class'],button[addon-key='text']");
    attrEle.each(function () {
        selector += "[" + jQuery.escapeSelector(jQuery(this).attr("addon-key")) + "='" + escapeSpecialCharacters(jQuery(this).attr("addon-value")) + "']";
    });

    return selector;
}

function getCssNavigationElement(ele) {
    var navBtnNumber = ele.attr("buttonNumber");
    var tabs = jQuery(".addon-footer .addon-elemtree-css div.addon-tabs[tabnumber='" + navBtnNumber + "']");
    var node = jQuery(".addon-footer .addon-elemtree-css button.navbuttons[buttonnumber='" + navBtnNumber + "']").text();
    // tabs.find("button[addon-key='id']").removeClass('addon-attrib-disabled').addClass('addon-attrib-enabled');
    // tabs.find("button[addon-key='name']").removeClass('addon-attrib-disabled').addClass('addon-attrib-enabled');
    node += getCssNavEleProperties(navBtnNumber);
    return node;
}

function changeEventHandlers(){
    jQuery("input[name='sortOrder']").change(function () {
       sortOrder= jQuery("input[name='sortOrder']:checked").val();        
    });
}



function populateLoc(element) {    
    chrome.storage.sync.set({
        'fromContextMenu': false
    });
    jQuery("#jqueryHide").show();
    jQuery("#xpathHide").show();
    jQuery("#xpath2Hide").show();
    jQuery("#cssHide").show();
    jQuery("#tagHide").show();
    $("element").trigger('mouseout');
    changeEventHandlers();
    currentElement = element;
    t = element;
    showElementTree(t);
    showJqueryElementTree(t);
    showXpathElementTree(t);
    var jqueryPath = getJquery(t);
    var Xpath2 = getXpath2(t);
    getXpath(t);
    getCssSelector(t);

    let encodedJqueryPath = encodeDoubleQoutes(jqueryPath);
    jQuery("#addonPath").html("<input type=\"radio\" name=\"locoptns\" toadd=\"" + "JQuerySelector.jQuery(" + encodedJqueryPath + "\"  toEval=\"" + encodedJqueryPath + "\"></input>" + "<b>Jquery : </b>" +
        "<span contenteditable=\"true\">" + encodeHtmlSpecialCharacters($.trim(jqueryPath)) + "</span>");

    let encodedXpath = encodeDoubleQoutes(currntXpath);
    jQuery("#addonXPath").html("<input type=\"radio\" name=\"locoptns\" toadd=\"" + "By.xpath(" + encodedXpath + "\"  toEval=\"" + encodedXpath + "\"></input>" + "<b>Xpath : </b>" +
        "<span contenteditable=\"true\">" + encodeHtmlSpecialCharacters($.trim(currntXpath)) + "</span>");

    jQuery("#addonXPath2").html("<input type=\"radio\" name=\"locoptns\" toadd=\"" + "By.xpath(" + Xpath2 + "\"  toEval=\"" + Xpath2 + "\"></input>" + "<b>Xpath-index based : </b>" +
        "<span contenteditable=\"true\">" + encodeHtmlSpecialCharacters($.trim(Xpath2)) + "</span>");

    let encodedCssSelector = encodeDoubleQoutes(cssSelector);
    jQuery("#addonCss").html("<input type=\"radio\" name=\"locoptns\" toadd=\"" + "By.cssSelector(" + encodedCssSelector + "\"  toEval=\"" + encodedCssSelector + "\"></input>" + "<b>Css Selector : </b>" +
        "<span contenteditable=\"true\">" + encodeHtmlSpecialCharacters(cssSelector) + "</span>");

    if (typeof jQuery(element).attr('id') == 'undefined') {
        jQuery("#idHide").hide();
        jQuery("#addonId").html("<span contenteditable=\"true\">none</span>");
    } else {
        jQuery("#idHide").show();
        var repId = t.getAttribute("id").replace(':', '\\:');
        jQuery("#addonId").html("<input type=\"radio\" name=\"locoptns\" toadd=\"" + "By.id(" + t.getAttribute("id") + "\"  toEval=\"#" + repId + "\"></input>" + "<b>Id : </b>" +
            "<span contenteditable=\"true\">" + t.getAttribute("id") + "</span>");
    }


    if (typeof jQuery(element).attr('name') == 'undefined') {
        jQuery("#nameHide").hide();
        jQuery("#addonName").html("<span contenteditable=\"true\">none</span>");

    } else {
        jQuery("#nameHide").show();
        jQuery("#addonName").html("<input type=\"radio\" name=\"locoptns\" toadd=\"" + "By.name(" + t.name + "\"  toEval=\"[name='" + t.name + "']\"></input>" + "<b>Name : </b>" +
            "<span contenteditable=\"true\">" + t.name + "</span>");
    }


    if (jQuery(element)[0].nodeName == 'A' && jQuery(element).text() && jQuery(element).text().length <= 15) {
        jQuery("#textHide").show();
        let encodedTextSelector = encodeDoubleQoutes(jQuery(element).text());
        jQuery("#addonText").html("<input type=\"radio\" name=\"locoptns\" toadd=\"" + "By.linkText(" + encodedTextSelector + "\"  toEval=\"a:contains('" + encodedTextSelector + "')\"></input>" + "<b>Link Text : </b>" +
            "<span contenteditable=\"true\">" + jQuery(element).text() + "</span>");
    } else {
        jQuery("#textHide").hide();
        jQuery("#addonText").html("<span contenteditable=\"true\">none</span>");
    }

    initSpan();

    if (iframeContent) {
        var message = "<b>Locator is inside the iframe: </b>";
        message += "iframe" + iframeInfo;
        displayAdditionalInfo(message);
    } else {
        hideAdditionalInfo();
    }

    jQuery(".addon-footer input[type=radio][name=locoptns]").on("change", function () {
        hideAdditionalInfo();
    });    
}

function checkForChanges()
{
    if (rootElement.css('height') != lastHeight)
    {
        lastHeight = rootElement.height();
        jQuery(".addon-sidebar").css("height",lastHeight+50);
    }
    setTimeout(checkForChanges, 50);
}

function initSpan() {
    jQuery(".addon-footer span").bindFirst('click',
        function (event) {
            jQuery(this).trigger({
                type: 'mousedown',
                which: 1
            });
            jQuery(jQuery(this).parent().children("input[name=\"locoptns\"]")).click();
        }
    );
    jQuery(".addon-footer span").on('DOMSubtreeModified',
        function () {
            var radioB = jQuery(jQuery(this).parent().children("input[name=\"locoptns\"]"));            
            try{
                radioB.attr('toEval', jQuery(this).text());
                radioB.attr('toAdd', radioB.attr('toAdd').split('(')[0] + '(' + jQuery(this).text());
            }
            catch(e){
                //handling the scenario where radioB.attr('toEval').text() is empty
            }
        }
    );
    jQuery(".addon-footer span").on('keypress',
        function (event) {
            event.stopPropagation();
            if (event.which === 13) {
                event.preventDefault();
                jQuery("div.addon-eval").click();
            }
        }
    );
}

function showGrid() {

    jQuery("#addonSelected").toggle();
    jQuery(".addon-eval").toggle();

    if (jQuery("#tableLayout").children().length > 0) {
        jQuery("#tableLayout").empty();
        jQuery("#uiOptions").show();
    } else {
        jQuery("#uiOptions").hide();
        jQuery("#tableLayout").empty();
        var samp = "";
        someBool = false;
        for (var each in objectMap) {
            someBool = true;
            index = objectMap[each].indexOf('(');
            split1 = objectMap[each].substr(0, index);
            split2 = objectMap[each].substr(index + 1);
            samp += "<tr class=\"tbl\" keyName=\"" + each + "\">" +
                "<td class=\"tbl\"><input type=\"checkbox\" removeKey=\"" + each + "\"></input>" +
                "</td><td class=\"tbl\">" + each +
                "</td><td class=\"tbl\">" + split1 +
                "</td><td class=\"tbl\">" + split2 +
                "</td></tr>";
        }
        jQuery("#tableLayout").append(
            "<div id=\"scrollable\">" +
            "<table class=\"tbl\">" +
            "<tr>" +
            "<th class=\"tbl1\"><input type=\"checkbox\" id=\"checkAll\"></input></th>" +
            "<th class=\"tbl1\">Locator name</th>" +
            "<th class=\"tbl1\">Type</th>" +
            "<th class=\"tbl1\">Value</th>" +
            "</tr>" +
            samp +
            "</table>" +
            "</div>");
        if (someBool) {
            jQuery("#tableLayout").append(
                "<br><button id=\"clearData\">Delete</button>"
            );
        } else {
            jQuery("#tableLayout").append(
                "<b>No locators saved to display</b>"
            );
        }
        jQuery("tr.tbl").dblclick(onGridRowClick);
        jQuery("tr.tbl").hover(function (event) {
            keyName = jQuery(this).attr("keyName");
            jQuery(".addon-highlight").removeClass("addon-highlight");
            if (objectMap[keyName].startsWith("By.xpath")) {
                var allElems = getElementsByXPath(objectMap[keyName].split('(')[1]);
                for (var eachElem in allElems) {
                    jQuery(allElems[eachElem]).not(".addon-footer, .addon-footer *").addClass("addon-highlight");
                }
            } else if (objectMap[keyName].startsWith("By.css")) {
                var allElems = document.querySelectorAll(objectMap[keyName].split('(')[1]);
                for (var eachElem in allElems) {
                    jQuery(allElems[eachElem]).not(".addon-footer, .addon-footer *").addClass("addon-highlight");
                }
            } else {
                toEval = "";
                if (objectMap[keyName].startsWith("By.id")) {
                    toEval = "#" + objectMap[keyName].split('(')[1];
                } else if (objectMap[keyName].startsWith("By.class")) {
                    toEval = "#" + objectMap[keyName].split('(')[1].split(' ').join('.');
                } else if (objectMap[keyName].startsWith("By.name")) {
                    toEval = "[name='" + objectMap[keyName].split('(')[1] + "']";
                } else {
                    toEval = objectMap[keyName].split('(')[1];
                }

                var hElem = jQuery(toEval + ":not(.addon-footer, .addon-footer *)");
                hElem.addClass("addon-highlight");
            }
            blinkHighlighted();
        });
        jQuery("tr.tbl").mouseout(
            function (event) {
                jQuery(".addon-highlight").removeClass("addon-highlight");
            }
        );
        jQuery("#clearData").click(function () {

            checkBoxes = $(".addon-footer input[type='checkbox']:checked:not(#checkAll)");
            if (checkBoxes.length == 0) {
                alert("No locators selected to delete !!!");
                return;
            }

            if (confirm("Selected locators data will be lost\n(This action can't be undone !!!)")) {
                for (var i = 0; i < checkBoxes.length; ++i) {
                    delete objectMap[$(checkBoxes[i]).attr("removekey")]
                    delete wholeMap[$(checkBoxes[i]).attr("removekey")]
                }
                chrome.storage.sync.set({
                    'bckObjectMap': objectMap
                });
                chrome.storage.sync.set({
                    'bckWholeMap': wholeMap
                });
                getFromChromeStorage();
                showGrid();
            }
        });



        jQuery("#checkAll").click(
            function () {
                $("input:checkbox").prop('checked', $(this).prop("checked"));
            }
        );

        jQuery("#keyname").on('keyup',
            function (event) {
                event.stopPropagation();
                jQuery("td.tbl:contains('" + jQuery("#keyname").val() + "'):nth-child(1)").parent().show();
                jQuery("td.tbl:not(:contains('" + jQuery("#keyname").val() + "')):nth-child(1)").parent().hide();
            }
        );
    }
}

function onGridRowClick() {
    var keyName = jQuery(this).attr("keyName");
    if (keyName) {
        isEditing = true;
        jQuery("[class^='addon-expand']").hide();
        jQuery("#addonSelected").toggle();
        jQuery(".addon-eval").toggle();
        var displayStr = "";
        var eachObj = wholeMap[keyName];
        jQuery("#uiOptions").show();
        jQuery("#tableLayout").empty();

        let encodedJquerySelector = encodeDoubleQoutes(eachObj["jquery"]);
        jQuery("#addonPath").html("<input type=\"radio\" name=\"locoptns\" toadd=\"" + "JQuerySelector.jQuery(" + encodedJquerySelector + "\"  toEval=\"" + encodedJquerySelector + "\"></input>" + "<b>Jquery : </b>" +
            "<span contenteditable=\"true\">" + eachObj["jquery"] + "</span>");

        let encodedXpath = encodeDoubleQoutes(eachObj["xpath"]);
        jQuery("#addonXPath").html("<input type=\"radio\" name=\"locoptns\" toadd=\"" + "By.xpath(" + encodedXpath + "\"  toEval=\"" + encodedXpath + "\"></input>" + "<b>Xpath : </b>" +
            "<span contenteditable=\"true\">" + eachObj["xpath"] + "</span>");

        jQuery("#addonXPath2").html("<input type=\"radio\" name=\"locoptns\" toadd=\"" + "By.xpath(" + eachObj["xpath2"] + "\"  toEval=\"" + eachObj["xpath2"] + "\"></input>" + "<b>Xpath-index based : </b>" +
            "<span contenteditable=\"true\">" + eachObj["xpath2"] + "</span>");

        let encodedCssSelector = encodeDoubleQoutes(eachObj["css"]);
        jQuery("#addonCss").html("<input type=\"radio\" name=\"locoptns\" toadd=\"" + "By.cssSelector(" + encodedCssSelector + "\"  toEval=\"" + encodedCssSelector + "\"></input>" + "<b>Css selector : </b>" +
            "<span contenteditable=\"true\">" + eachObj["css"] + "</span>");

        jQuery("#addonId").html("<input type=\"radio\" name=\"locoptns\" toadd=\"" + "By.id(" + eachObj["id"] + "\"  toEval=\"#" + eachObj["id"] + "\"></input>" + "<b>Id : </b>" +
            "<span contenteditable=\"true\">" + eachObj["id"] + "</span>");

        let encodedTextSelector = encodeDoubleQoutes(eachObj["text"]);
        jQuery("#addonText").html("<input type=\"radio\" name=\"locoptns\" toadd=\"" + "By.linkText(" + encodedTextSelector + "\"  toEval=\"a:contains('" + encodedTextSelector + "')\"></input>" + "<b>Link Text : </b>" +
            "<span contenteditable=\"true\">" + eachObj["text"] + "</span>");

        jQuery("#addonName").html("<input type=\"radio\" name=\"locoptns\" toadd=\"" + "By.name(" + eachObj["name"] + "\" toEval=\"[name='" + eachObj["name"] + "']\"></input>" + "<b>Name : </b>" +
            "<span contenteditable=\"true\">" + eachObj["name"] + "</span>");

        jQuery("#keyname").val(keyName);

        jQuery("#jqueryHide").show();
        jQuery("#xpathHide").show();
        jQuery("#xpath2Hide").show();
        jQuery("#cssHide").show();

        if (jQuery("#addonId > span").text() == "none") {
            jQuery("#idHide").hide();
        } else {
            jQuery("#idHide").show();
        }

        if (jQuery("#addonText > span").text() == "none") {
            jQuery("#textHide").hide();
        } else {
            jQuery("#textHide").show();
        }

        if (jQuery("#addonName > span").text() == "none") {
            jQuery("#nameHide").hide();
        } else {
            jQuery("#nameHide").show();
        }
        jQuery(".addon-footer span").dblclick(
            function () {
                jQuery(this).focus();
            }
        );

        initSpan();
    }
}

function addBackupValues() {
    var eachKey = {};
    eachKey['jquery'] = jQuery("#addonPath > span").text();
    eachKey['xpath'] = jQuery("#addonXPath > span").text();
    eachKey['xpath2'] = jQuery("#addonXPath2 > span").text();
    eachKey['css'] = jQuery("#addonCss > span").text();
    eachKey['id'] = jQuery("#addonId > span").text();
    eachKey['text'] = jQuery("#addonText > span").text();
    eachKey['name'] = jQuery("#addonName > span").text();
    wholeMap[jQuery("#keyname").val()] = eachKey;
}

function validateKeyName() {
    var keyNameValue = jQuery("#keyname").val();
    if (keyNameValue) { } else {
        alert("Key name can't be left blank while adding locators");
        return false;
    }
    if (! /^[a-zA-Z_$][a-zA-Z_$0-9]*$/.test(keyNameValue)) {
        alert("Key name should be a valid java variable name");
        return false;
    }
    if (keyNameValue.includes(" ") || keyNameValue.includes("=")) {
        alert("space and '=' are invalid characters while giving Key name ");
        return false;
    }
    if (isEditing == false) {
        for (var eachName in objectMap) {
            if (eachName == keyNameValue) {
                alert("Locator with given key name is already exist in added Locators");
                return false;
            }
        }
    }
    if (jQuery("input[name=\'locoptns\']:checked").length == 0) {
        alert("Select a locator to add");
        return false;
    }
    return true;
}

function download(filename, text) {
    var element = document.createElement('a');
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
    element.setAttribute('download', filename);

    element.style.display = 'none';

    document.body.appendChild(element);

    jQuery(element).click(function (e) {
        e.stopPropagation();
    });

    element.click();

    document.body.removeChild(element);
}

function saveFunction(e) {
    if (e.ctrlKey && e.keyCode == 88) {
        // jQuery(".addon-footer").data("stop", !jQuery(".addon-footer").data("stop"));
        // jQuery(".addon-footer").toggleClass("addon-foter-save");
        // if (jQuery("#overlay").is(":hidden")) {
        //     showOverLay();
        // }
        // e.stopPropagation();
        // e.preventDefault();
    }

    if (addonlastElement != null && typeof addonlastElement != 'undefined') {
        if (e.keyCode == 46) {

            addonlastElement.remove();
            addonlastElement = null;
        }
    }
};

function syncToChromeStorage() {
    chrome.storage.sync.set({
        'bckObjectMap': objectMap
    });
    chrome.storage.sync.set({
        'bckWholeMap': wholeMap
    });
};

function getFromChromeStorage() {
    chrome.storage.sync.get('bckObjectMap', function (data) {
        if (data.bckObjectMap) {
            objectMap = data.bckObjectMap;
        } else {
            objectMap = {};
        }
    });
    chrome.storage.sync.get('bckWholeMap', function (data) {
        if (data.bckWholeMap) {
            wholeMap = data.bckWholeMap;
        } else {
            wholeMap = {};
        }
    });
}

function removeAddon() {
    jQuery(".addon-footer").remove();
    removeOverLay();
};

function initButton() {
    jQuery('.addon-close-button').click(function () {
        isExtesionClose = true;
        removeAddon();
        window.onbeforeunload = function () {
            return null;
        };
    });

    jQuery(".addon-addsettings-button").click(showGrid);
    jQuery(".addon-clipbrd-button").click(getMapOutput);

    jQuery('.addon-copy-button').click(function () {
        sampBool = true
        for (each in objectMap) {
            sampBool = false
        }
        if (sampBool) {
            alert("No locators added to download");
            return;
        }
        jQuery("#clipBrdDropDn").removeClass("addon-show");
        jQuery("#downloadDropDn").toggleClass("addon-show");

    })
};

function getMapOutput() {
    sampBool = true
    for (each in objectMap) {
        sampBool = false
    }
    if (sampBool) {
        alert("No locators added to copy");
        return;
    }
    jQuery("#downloadDropDn").removeClass("addon-show");
    jQuery("#clipBrdDropDn").toggleClass("addon-show");
}

function initKeyCapture() {
    jQuery(document).off('keydown');
    jQuery(document).on('keydown', saveFunction);
};

function injectJquery(jqueryUrl) {
    var script = document.createElement('script');
    var head = document.getElementsByTagName('head')[0];
    var done = false;
    script.onload = script.onreadystatechange = (function () {
        if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
            done = true;
            script.onload = script.onreadystatechange = null;
            head.removeChild(script);
        }
    });
    script.src = jqueryUrl;
    script.type = 'text/javascript';
    head.appendChild(script);
}

function injectJqueryUrls() {
    if (window.jQuery != undefined && jQuery.active == 0) {
        var head = document.getElementsByTagName("head")[0];
        var script = document.createElement("script");
        var version = "3.0.0";
        var scriptSource = 'https://ajax.googleapis.com/ajax/libs/jquery/' + version + '/jquery.min.js';
        script.type = "text/javascript";
        script.src = "\"" + scriptSource + "\"";
        script.id = "jq_source";
        script.innerHTML = "var $ = jQuery.noConflict()";
        var script2 = document.createElement("script");
        scriptSource = 'https://ajax.aspnetcdn.com/ajax/jQuery/jquery-' + version + '.min.js';
        script2.type = "text/javascript";
        script2.src = "\"" + scriptSource + "\"";
        if (!document.getElementById("jq_source")) {
            head.appendChild(script);
            head.appendChild(script2);
        }
        else {
            document.getElementById("jq_source").src = "\"" + scriptSource + "\"";
        }
    }
}

function preventPageLoad() {
    window.onbeforeunload = function () {
        return "Please don't allow to load page while capturing elements !!!";
    }
}

function injectOverLay() {
    jQuery("body").append("<div id=\"overlay\"></div>");
    hideOverLay();
}

function removeOverLay() {
    jQuery("#overlay").remove();
}

function showOverLay() {
    jQuery("#overlay").hide();
}

function hideOverLay() {
    jQuery("#overlay").hide();
}

//injectJqueryUrls();

jQuery.fn.bindFirst = function (name, fn) {
    var elem, handlers, i, _len;
    this.bind(name, fn);
    for (i = 0, _len = this.length; i < _len; i++) {
        elem = this[i];
        handlers = jQuery._data(elem).events[name.split('.')[0]];
        handlers.unshift(handlers.pop());
    }
    return this;
};

function checkContextClick() {
    chrome.storage.sync.get('fromContextMenu', function (data) {
        if (data.fromContextMenu) {
            chrome.storage.sync.get('rightXpath', function (data) {
                contextElement = getElementsByXPath(data.rightXpath.rightXpath)[0];
            });

        }
    });
}
function generateContextElement() {
    chrome.storage.sync.get('fromContextMenu', function (data) {
        if (data.fromContextMenu) {
            populateLoc(contextElement);
        }
    });
}

function blinkHighlighted() {
    setTimeout(function () {
        var iframes = document.getElementsByTagName("iframe");
        for (var i = 0; i < iframes.length; i++) {
            jQuery(iframes[i]).contents().find(".addon-highlight").effect(
                "bounce", { direction: 'up', distance: 5, times: 1 }, 200, function () { }
            );
        }
        jQuery(".addon-highlight").effect(
            "bounce", { direction: 'up', distance: 5, times: 1 }, 200, function () { }
        );
    }, 500);
}

jQuery(function () {
    removeAddon();
    jQuery(".addon-footer").contextmenu(function () { });
    setTimeout(
        function () {
            checkContextClick();
        }, 100
    );
    setTimeout(
        function () {
            getFromChromeStorage();
            preventPageLoad();
            createFooter();
            initButton();
            initKeyCapture();
            generateContextElement();
        }, 200
    );
});


function displayAdditionalInfo(message) {
    $('#info-notify').html(message).stop().fadeOut(150).fadeIn(200);
}

function hideAdditionalInfo() {
    $('#info-notify').html("").stop().fadeOut(150);
}

function hiddenElementsCount(elements, iframeContentWindow) {
    var counter = 0;
    if (!elements || typeof elements == "undefined")
        return counter;

    for (var i = 0; i < elements.length; i++) {
        if (isElementHidden(elements[i], iframeContentWindow))
            counter++;
    }
    return counter;
}

function isElementHidden(el, iframeContentWindow) {
    if (iframeContentWindow && !(el instanceof iframeContentWindow.HTMLElement))
        return false;
    else if (!iframeContentWindow && (!el || !(el instanceof Element)))
        return false;

    var style = window.getComputedStyle(el);
    if (style.display.indexOf('none') > -1 || style.visibility.indexOf('hidden') > -1)
        return true;

    return isElementHidden(el.parentNode);
}

function encodeDoubleQoutes(item) {
    return item.replace(/"/g, "&quot;");
}

function escapeSpecialCharacters(item) {
    return item.replace(/'/g, "\\'");
}

function getCombinations(items, postfix = '') {
    var result = [];
    var f = function (prefix, items) {
        for (var i = 0; i < items.length; i++) {
            result.push(prefix + items[i]);
            f(prefix + items[i] + postfix, items.slice(i + 1));
        }
    }
    f('', items);
    return result;
}

function getFirstTextNodeValue(element) {
    if (element instanceof jQuery) {
        element = element[0];
    }

    var nodes = element.childNodes;
    var textNodeValue = ''
    for (let i = 0; i < nodes.length; i++) {
        if (nodes[i].nodeType === Node.TEXT_NODE) {
            textNodeValue = nodes[i].nodeValue;
            break;
        }
    }
    return textNodeValue;
}

function decodeHtmlSpecialCharacters(text){
    let keys = Object.keys(decodeCharacters);
    keys.forEach((key) => {
        if (text.includes(key)) {
            text = text.replace(key, decodeCharacters[key]);
        }
    });
    return text;
}

function encodeHtmlSpecialCharacters(text){
    let keys = Object.keys(encodeCharacters);
    keys.forEach((key) => {
        if (text.includes(key)) {
            text = text.replace(key, encodeCharacters[key]);
        }
    });
    return text;
}